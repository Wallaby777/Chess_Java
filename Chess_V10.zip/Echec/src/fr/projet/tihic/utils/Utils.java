package fr.projet.tihic.utils;

import java.util.HashMap;
import java.util.Map;

import fr.projet.tihic.reference.PositionId;

public class Utils {
	
	
	//Méthode permetant l'obtention des coordonné de la position ou la position.
	
	public static Map<String, Integer> getCoordinate(String position) {
		if (position == null || position.length() != 2) {
			System.out.println("ERROR");
			return null;
		}

		Map<String, Integer> coordinateToReturn = new HashMap<String, Integer>();

		String column = position.substring(0, 1).toUpperCase();

		int line = Integer.parseInt(position.substring(1, 2));


		coordinateToReturn.put(PositionId.LINE, line);

		switch (column) {
		case "A":
			coordinateToReturn.put(PositionId.COLUMN, 1);
			return coordinateToReturn;

		case "B":
			coordinateToReturn.put(PositionId.COLUMN, 2);
			return coordinateToReturn;

		case "C":
			coordinateToReturn.put(PositionId.COLUMN, 3);
			return coordinateToReturn;

		case "D":
			coordinateToReturn.put(PositionId.COLUMN, 4);
			return coordinateToReturn;

		case "E":
			coordinateToReturn.put(PositionId.COLUMN, 5);
			return coordinateToReturn;

		case "F":
			coordinateToReturn.put(PositionId.COLUMN, 6);
			return coordinateToReturn;

		case "G":
			coordinateToReturn.put(PositionId.COLUMN, 7);
			return coordinateToReturn;

		case "H":
			coordinateToReturn.put(PositionId.COLUMN, 8);
			return coordinateToReturn;

		default:
			break;
		}
		return null;
	}

	// Get the position form the coordinate
	public static String getPositionFromCoordinate(Map<String, Integer> coordinate) {
		// methode containsKey return a boolean, so if coordinate.containsKey does not
		// contain "column", this methode return false. '!' inverse the return value
		if (!coordinate.containsKey(PositionId.COLUMN) || !coordinate.containsKey(PositionId.LINE)) {
			System.out.println("ERROR");
			return null;
		}

		String position = "";

		switch (coordinate.get(PositionId.COLUMN)) {
		case 1:
			position += "A";
			break;

		case 2:
			position += "B";
			break;

		case 3:
			position += "C";
			break;
		case 4:
			position += "D";
			break;
		case 5:
			position += "E";
			break;
		case 6:
			position += "F";
			break;
		case 7:
			position += "G";

			break;
		case 8:
			position += "H";
			break;

		default:
			break;
		}
		position += coordinate.get(PositionId.LINE).toString();

		return position;
	}
}
