package fr.projet.tihic.service;

import fr.projet.tihic.player.Player;

public interface IServicePlayer  extends IServiceCrud<Player>{
	
	public Player create(String name, boolean isIA, String color, int iaValeur);

}
