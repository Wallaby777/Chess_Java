package fr.projet.tihic.service;

import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.Rook;


public interface IServiceAbstractPiece extends IServiceCrud < AbstractPiece >
{    
    public AbstractPiece create(String pieceType, String color);

}
