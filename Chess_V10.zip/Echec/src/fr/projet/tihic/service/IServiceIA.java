package fr.projet.tihic.service;

import java.util.List;
import java.util.Map;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.interfa.Game;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.service.impl.move.ServiceMove;
import fr.projet.tihic.service.impl.rules.ServiceRules;
import fr.projet.tihic.wip.WorkInProgress;

public interface IServiceIA {
	
	public boolean moveIA(Board board, ServiceMove service, ServiceRules serviceRule, WorkInProgress work, List<AbstractPiece> chaud, String posDepart, String posFin, int forceIa, Game game);

	public Board initBoardClone(Board board);
	
	public Map<String, String> minMax(Board board, Board boardC, ServiceMove service, int depth);
	
	public int minMaxRec(Board boardC, ServiceMove service, boolean minmax, int depth, int bestMove);
}
