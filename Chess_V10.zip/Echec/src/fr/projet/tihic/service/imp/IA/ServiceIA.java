package fr.projet.tihic.service.imp.IA;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.interfa.Game;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.King;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.reference.ColorId;
import fr.projet.tihic.reference.PieceId;
import fr.projet.tihic.reference.PositionId;
import fr.projet.tihic.service.IServiceIA;
import fr.projet.tihic.service.impl.move.ServiceMove;
import fr.projet.tihic.service.impl.piece.ServiceAbstractPiece;
import fr.projet.tihic.service.impl.rules.ServiceRules;
import fr.projet.tihic.utils.Utils;
import fr.projet.tihic.wip.WorkInProgress;

public class ServiceIA implements IServiceIA {

	
	//Service Mouvement de l'IA
	@Override
	public boolean moveIA(Board board, ServiceMove service, ServiceRules serviceRule, WorkInProgress work, List<AbstractPiece> chaud, String posDepart, String posFin, int forceIa, Game game) {
		
		Board boardC = new Board();
		

		Map<String, String> depart = new HashMap<String, String>();
		List<String> keys = new ArrayList<String>();			
		
		int compteur = 0;
		int bestMove = -9999;
		int best = -9999;
		
		String posDepIa = "";
		String posFiIa = "";
		
		
		boardC = initBoardClone(board);//initialise un Clone du board initiale.			
		depart = minMax(board, boardC, service, forceIa);//Recherche du meilleurs coup possible sur une profondeur de recherche fixé.
	
		//Parcours la liste de coup possible est choissie le meilleurs dans la liste.
		for(Map.Entry<String, String> entry : depart.entrySet()) {
			keys.add(entry.getKey());
			
			compteur += 1;
			bestMove = Math.max(bestMove, board.getChessBoard().get(entry.getKey()).getValueMove());//Prend le meilleurs coup graçe a la valeurs de mouvement assignier pour la piece dans le minmax.
			
			if(bestMove>best) {
				best = bestMove;
				posDepIa = entry.getKey();
				posFiIa = depart.get(posDepIa);
			}
			if(compteur == depart.size() && bestMove==best) {
				posDepIa = keys.get((int) (Math.random() * (keys.size()-1)));
				posFiIa = depart.get(posDepIa);
			}
		}
		
		if(depart.isEmpty()) {
			
			
			chaud = serviceRule.echecMat(ColorId.COLOR_WHITE, service, board, work, chaud);
			if (chaud.isEmpty()) return false;
			
				
			else {
				AbstractPiece piece = chaud.get((int) (Math.random()*(chaud.size()-1)));
				posDepIa = Utils.getPositionFromCoordinate(piece.getPosition());
				posFiIa = piece.getPossiblePath().get((int) (Math.random()*(piece.getPossiblePath().size()-1)));
				
				work.gameProgress(posFiIa, posDepIa, ColorId.COLOR_BLACK, board);

				serviceRule.promotion(board, work.getPlayer().get(1), work, null);

				board.getChessBoard().get(posFiIa).setPosition(Utils.getCoordinate(posFiIa));
				board.getChessBoard().get(posFiIa).setPossiblePath(null);

				serviceRule.castlingProgress(board, posFiIa, ColorId.COLOR_BLACK);

				work.setFirstMovePiece(posDepIa, posFiIa, ColorId.COLOR_BLACK, board, serviceRule, work);
				WorkInProgress.setNbcoup_tot((WorkInProgress.getNbcoup_tot() + 1));

				return true;
				
			}
		
		
		
	}else {

		work.gameProgress(posFiIa, posDepIa, ColorId.COLOR_BLACK, board);

		serviceRule.promotion(board, work.getPlayer().get(1), work, null);

		board.getChessBoard().get(posFiIa).setPosition(Utils.getCoordinate(posFiIa));
		board.getChessBoard().get(posFiIa).setPossiblePath(null);

		serviceRule.castlingProgress(board, posFiIa, ColorId.COLOR_BLACK);

		work.setFirstMovePiece(posDepIa, posFiIa, ColorId.COLOR_BLACK, board, serviceRule, work);
		WorkInProgress.setNbcoup_tot((WorkInProgress.getNbcoup_tot() + 1));

		return true;
	
	}
		
	}
	
	
	//Fonction principale de la recherche de meilleurs coups (base de l'algorithme minmax) Appelle une fonction recursive pour explorer toute les possibilitées.
	@Override
	public Map<String, String> minMax(Board board, Board boardC, ServiceMove service, int depth) {
		ServiceRules serviceRule = new ServiceRules();
		
		Map<String, List<String>> possibleMove = new HashMap<String, List<String>>();
		Map<String, String> bestCalcul = new HashMap<String, String>();
		
		//best et bestMove permette de nous donner le déplacement le plus judicieux.
		int best = -9999;
		
		//L'IA est toujours noir. On récupere l'ensemble des coups possible pour toute les pièces noir.
		for (Map.Entry<String, AbstractPiece> entry : boardC.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				if (entry.getValue().getColor().equals(ColorId.COLOR_BLACK)) {
					if (!service.getMove(entry.getValue(), boardC, false, false, true, false, null).isEmpty()) {
						possibleMove.put(entry.getKey(),
								service.getMove(entry.getValue(), boardC, false, false, true, false, null));
					}
					if(entry.getValue() instanceof King) {
						possibleMove.put(entry.getKey(), serviceRule.castling(boardC, ColorId.COLOR_BLACK));
					}
				}
			}
		}
		
		//Parcours de la HashMap pour evaluer chacun des coups possible pour toute les pièces pouvant se déplacer.
		for (Map.Entry<String, List<String>> entry : possibleMove.entrySet()) {

			for (int j = 0; j < possibleMove.get(entry.getKey()).size(); j++) {
				if (possibleMove.get(entry.getKey()).get(j) != null && entry.getValue() != null) {
					
					// Initialise au plus bas possible la valeur de meilleurs coup.
					int bestMove = -9999;

					
					// Si la case pouvant etre exploré n'est pas nul on incrémente la valeurs de
					// bestmove en fonction de la valeur apposé à la piece adverse.
					if (boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)) != null) {
						bestMove += boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)).getValueForIA() ;
					}
					
					// On explore cette case donc on update le boardClone.
					boardC.getChessBoard().put(possibleMove.get(entry.getKey()).get(j), boardC.getChessBoard().get(entry.getKey()));
					boardC.getChessBoard().put(entry.getKey(), null);
					boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)).setPosition(Utils.getCoordinate(possibleMove.get(entry.getKey()).get(j)));
					boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)).setPossiblePath(null);
					
					// On appelle la fonction minmaxRecursive pour explorer toute les possibilitées
					// liée à se déplacement, elle nous retournera le score maximal.
					bestMove = Math.max(bestMove, minMaxRec(boardC, service, false, depth, bestMove));
					
					// Si la valeurs retourner est superieur ou egale à bestmove alors elle est
					// enregistré.
					if (bestMove >= best) {
						best = bestMove;
						board.getChessBoard().get(entry.getKey()).setValueMove(bestMove);
						bestCalcul.put(entry.getKey(), possibleMove.get(entry.getKey()).get(j));
					}
					
					// On reinitialise notre boardClone à la mesure de notre board initiale.
					boardC = initBoardClone(board);
				}
			}

		}
		return bestCalcul;
		
		
	}

	
	//initialise un Board Clone.
	@Override
	public Board initBoardClone(Board board) {
		Board boardC = new Board();
		ServiceAbstractPiece serviceAbstractPiece = new ServiceAbstractPiece();
		Map<String, AbstractPiece> boardClone = new HashMap<String, AbstractPiece>();
		
		
		//Recopie du board initiale.
		for(Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				boardClone.put(entry.getKey(),serviceAbstractPiece.create(entry.getValue().getType(), entry.getValue().getColor()));
				
				//On sete les différentes caractéristique des pièce du nouveaux board à partir du board initiale.
				if (board.getChessBoard().get(entry.getKey()) instanceof Rook) {
					Rook rook = (Rook) board.getChessBoard().get(entry.getKey());
					Rook rookC = (Rook) boardClone.get(entry.getKey());
					rookC.setIsFirstMove(rook.getFirstMove());
				}
				if (board.getChessBoard().get(entry.getKey()) instanceof King) {
					King king = (King) board.getChessBoard().get(entry.getKey());
					King kingC = (King) boardClone.get(entry.getKey());
					kingC.setFirstMove(king.isFirstMove());
				}
				if (board.getChessBoard().get(entry.getKey()) instanceof Pawn) {
					Pawn pawn = (Pawn) board.getChessBoard().get(entry.getKey());
					Pawn pawnC = (Pawn) boardClone.get(entry.getKey());
					pawnC.setFirstMove(pawn.isFirstMove());
					for(Map.Entry<String, Integer> entry1 : pawnC.getEnPassant().entrySet()) {
						pawnC.setEnPassant(entry1.getKey(), entry1.getValue());
					}
				}
				
			}
			else boardClone.put(entry.getKey(), null ); 
		}
		
		//On set les positions des pièces sur le nouveaux board.
		Set<String> keys = boardClone.keySet();
		for (String key : keys) {
			if (boardClone.get(key) != null) {
				boardClone.get(key).setPosition(Utils.getCoordinate(key));
			}
		}
		
		boardC.setChessBoard(boardClone);
		
		return boardC;
	}

	
	//fonction minMaxRecursive qui va explorer toute les situations possible liée à notre déplacement et lui attribura un score.
	public int minMaxRec(Board boardC, ServiceMove service, boolean minmax, int depth, int bestMove) {
		Map<String, List<String>> possibleMove = new HashMap<String, List<String>>();
		
		//On crée et on clone à nouveaux un board à partir du board Clone Permet des re-initialisation des pieces de leurs mouvements possible ect.(apres chaque fin de recursion.
		Board boardCbis = new Board();
		boardCbis = initBoardClone(boardC);
		
		//condition permetant de mettre fin à la recursion.
		if(depth == 0) {
			return bestMove;
		}
		
		//Si c'est le tour des noirs. Meme logique que la fonction minmax, exploration recursive.
		if(minmax) {
			
			for (Map.Entry<String, AbstractPiece> entry : boardC.getChessBoard().entrySet()) {
				if (entry.getValue() != null) {
					if (entry.getValue().getColor().equals(ColorId.COLOR_BLACK)) {
						if (!service.getMove(entry.getValue(), boardC, false, false, true, false, null).isEmpty()) {
							possibleMove.put(entry.getKey(),service.getMove(entry.getValue(), boardC, false, false, true, false, null));
						}
					}			
				}
			}
			if (possibleMove != null) {
				for (Map.Entry<String, List<String>> entry : possibleMove.entrySet()) {

					for (int j = 0; j < possibleMove.get(entry.getKey()).size(); j++) {
						if (entry.getValue() != null) {

							if (boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)) != null) {
								bestMove += boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j))
										.getValueForIA();
							}

							boardC.getChessBoard().put(possibleMove.get(entry.getKey()).get(j), boardC.getChessBoard().get(entry.getKey()));
							boardC.getChessBoard().put(entry.getKey(), null);
							boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)).setPosition(Utils.getCoordinate(possibleMove.get(entry.getKey()).get(j)));
							boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)).setPossiblePath(null);
							
							
							bestMove = Math.max(bestMove,
									minMaxRec(boardC, service, false, depth - 1, bestMove));
							
							
							boardC = initBoardClone(boardCbis);
						}
					}
				}
			}
			return bestMove;
		//Si c'est au tour des blancs.
		} else {
			
			for (Map.Entry<String, AbstractPiece> entry : boardC.getChessBoard().entrySet()) {
				if (entry.getValue() != null) {
					if (entry.getValue().getColor().equals(ColorId.COLOR_WHITE)) {
						if (!service.getMove(entry.getValue(), boardC, false, false, true, false, null).isEmpty()) {
							possibleMove.put(entry.getKey(),
									service.getMove(entry.getValue(), boardC, false, false, true, false, null));
						}
					}
				}
			}
			if (possibleMove != null) {
				for (Map.Entry<String, List<String>> entry : possibleMove.entrySet()) {

					for (int j = 0; j < possibleMove.get(entry.getKey()).size(); j++) {
						if (entry.getValue() != null) {

							if (boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)) != null) {
								bestMove += boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j))
										.getValueForIA();
							}

							boardC.getChessBoard().put(possibleMove.get(entry.getKey()).get(j), boardC.getChessBoard().get(entry.getKey()));
							boardC.getChessBoard().put(entry.getKey(), null);
							boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)).setPosition(Utils.getCoordinate(possibleMove.get(entry.getKey()).get(j)));
							boardC.getChessBoard().get(possibleMove.get(entry.getKey()).get(j)).setPossiblePath(null);

							
							bestMove = Math.min(bestMove,
									minMaxRec(boardC, service, true, depth-1, bestMove));
							
						
							boardC = initBoardClone(boardCbis);
						}
					}
				}
			}
			return bestMove;
		}

	}

}
