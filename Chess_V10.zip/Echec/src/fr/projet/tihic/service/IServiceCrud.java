package fr.projet.tihic.service;

public interface IServiceCrud<T>
{
    public T create();
    
    public T get (String reference);
    

}
