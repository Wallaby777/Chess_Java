package fr.projet.tihic.service;

import java.util.List;
import java.util.Map;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.interfa.Game;
import fr.projet.tihic.interfa.Promotion;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.King;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.player.Player;
import fr.projet.tihic.service.impl.move.ServiceMove;
import fr.projet.tihic.wip.WorkInProgress;

public interface IServiceRules {
	
	
	public Promotion promotion(Board board, Player player, WorkInProgress work, Game game);
	
	public List<String> castling(Board board, String ride);
	
	public void castlingProgress(Board board, String position, String ride);
	
	public void enPassant(Board board, String start, String end, WorkInProgress work);
	
	public boolean echecCheck(Board board, ServiceMove service, String color);
	
	public List<AbstractPiece> echecPiece(Board board, ServiceMove service, String color);
	
	public List<String> echecPath(Board board, ServiceMove service, String color);
	
	public boolean echecPathRestrict(Board board, List<String> move, String position);
	
	public AbstractPiece echecKing(Board board, ServiceMove service, String color);
	
	public boolean autoeizedPath(Board board, String keytoinit, String possibleMove, String kingPosition);
	
	public List<AbstractPiece> echecMat(String ride, ServiceMove service, Board chessBoard, WorkInProgress work, List<AbstractPiece> chaud);

	
}
