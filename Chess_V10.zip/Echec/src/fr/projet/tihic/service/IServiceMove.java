package fr.projet.tihic.service;

import java.util.List;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.Bishop;
import fr.projet.tihic.piece.King;
import fr.projet.tihic.piece.Knight;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Queen;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.wip.WorkInProgress;

public interface IServiceMove {

	public List<String> getMove(AbstractPiece piece, Board board, boolean integral, boolean echec, boolean autorize, boolean pion, String pos);

	public List<String> pawnMove(Pawn pawn, Board board, boolean integral, boolean echec,boolean autorize,boolean pion, String pos);

	public List<String> rookMove(AbstractPiece rookOrQueen, Board board, boolean integral, boolean echec,boolean autorize, String pos);

	public List<String> bishopMove(AbstractPiece bishopOrQueen, Board board, boolean integral, boolean echec,boolean autorize, String pos);

	public List<String> knightMove(Knight knight, Board board, boolean integral, boolean echec,boolean autorize, String pos);

	public List<String> queenMove(Queen queen, Board board, boolean integral, boolean echec,boolean autorize, String pos);

	public List<String> kingMove(King king, Board board, boolean autorize);
}
