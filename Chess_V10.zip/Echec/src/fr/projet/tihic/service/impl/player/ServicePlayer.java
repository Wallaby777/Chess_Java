package fr.projet.tihic.service.impl.player;


import java.util.ArrayList;
import java.util.List;

import fr.projet.tihic.player.Player;
import fr.projet.tihic.service.IServicePlayer;

public class ServicePlayer implements IServicePlayer{

	@Override
	public Player create() {
		// Not used
		return null;
	}

	@Override
	public Player get(String reference) {
		// Not used
		return null;
	}

	@Override
	public Player create(String name, boolean isIA, String color, int iaValeur) {
		Player player = new Player();
		player.setName(name);
		player.setColor(color);
		player.setIA(isIA);
		player.setTime(0);
		player.setValueOfIA(iaValeur);
		return player;
	}

}
