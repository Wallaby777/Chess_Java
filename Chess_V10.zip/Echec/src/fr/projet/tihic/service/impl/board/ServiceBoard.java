package fr.projet.tihic.service.impl.board;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.reference.ColorId;
import fr.projet.tihic.reference.PieceId;
import fr.projet.tihic.service.IServiceBoard;
import fr.projet.tihic.service.impl.piece.ServiceAbstractPiece;
import fr.projet.tihic.utils.Utils;

public class ServiceBoard implements IServiceBoard {

	private ServiceAbstractPiece serviceAbstractPiece = new ServiceAbstractPiece();

	@Override
	public Board get(String reference) {
		// TODO Auto-generated method stub
		return null;
	}

	//Initialisation du board.
	@Override
	public Board create() {
		Board board = new Board();
		Map<String, AbstractPiece> chessBoard = new HashMap<String, AbstractPiece>();
		chessBoard.put("A1", serviceAbstractPiece.create(PieceId.ROOK_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("A2", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("A3", null);
		chessBoard.put("A4", null);
		chessBoard.put("A5", null);
		chessBoard.put("A6", null);
		chessBoard.put("A7", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("A8", serviceAbstractPiece.create(PieceId.ROOK_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("B1", serviceAbstractPiece.create(PieceId.KNIGHT_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("B2", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("B3", null);
		chessBoard.put("B4", null);
		chessBoard.put("B5", null);
		chessBoard.put("B6", null);
		chessBoard.put("B7", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("B8", serviceAbstractPiece.create(PieceId.KNIGHT_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("C1", serviceAbstractPiece.create(PieceId.BISHOP_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("C2", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("C3", null);
		chessBoard.put("C4", null);
		chessBoard.put("C5", null);
		chessBoard.put("C6", null);
		chessBoard.put("C7", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("C8", serviceAbstractPiece.create(PieceId.BISHOP_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("D1", serviceAbstractPiece.create(PieceId.QUEEN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("D2", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("D3", null);
		chessBoard.put("D4", null);
		chessBoard.put("D5", null);
		chessBoard.put("D6", null);
		chessBoard.put("D7", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("D8", serviceAbstractPiece.create(PieceId.QUEEN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("E1", serviceAbstractPiece.create(PieceId.KING_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("E2", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("E3", null);
		chessBoard.put("E4", null);
		chessBoard.put("E5", null);
		chessBoard.put("E6", null);
		chessBoard.put("E7", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("E8", serviceAbstractPiece.create(PieceId.KING_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("F1", serviceAbstractPiece.create(PieceId.BISHOP_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("F2", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("F3", null);
		chessBoard.put("F4", null);
		chessBoard.put("F5", null);
		chessBoard.put("F6", null);
		chessBoard.put("F7", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("F8", serviceAbstractPiece.create(PieceId.BISHOP_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("G1", serviceAbstractPiece.create(PieceId.KNIGHT_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("G2", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("G3", null);
		chessBoard.put("G4", null);
		chessBoard.put("G5", null);
		chessBoard.put("G6", null);
		chessBoard.put("G7", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("G8", serviceAbstractPiece.create(PieceId.KNIGHT_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("H1", serviceAbstractPiece.create(PieceId.ROOK_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("H2", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_WHITE));
		chessBoard.put("H3", null);
		chessBoard.put("H4", null);
		chessBoard.put("H5", null);
		chessBoard.put("H6", null);
		chessBoard.put("H7", serviceAbstractPiece.create(PieceId.PAWN_LABEL, ColorId.COLOR_BLACK));
		chessBoard.put("H8", serviceAbstractPiece.create(PieceId.ROOK_LABEL, ColorId.COLOR_BLACK));

		Set<String> keys = chessBoard.keySet();
		for (String key : keys) {
			if (chessBoard.get(key) != null) {
				chessBoard.get(key).setPosition(Utils.getCoordinate(key));
			}
		}

		board.setChessBoard(chessBoard);
		return board;
	}

	public ServiceAbstractPiece getServiceAbstractPiece() {
		return serviceAbstractPiece;
	}

	public void setServiceAbstractPiece(ServiceAbstractPiece serviceAbstractPiece) {
		this.serviceAbstractPiece = serviceAbstractPiece;
	}

}
