package fr.projet.tihic.service.impl.move;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.plaf.basic.BasicSplitPaneUI.KeyboardResizeToggleHandler;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.interfa.Game;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.Bishop;
import fr.projet.tihic.piece.King;
import fr.projet.tihic.piece.Knight;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Queen;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.reference.ColorId;
import fr.projet.tihic.reference.PieceId;
import fr.projet.tihic.reference.PositionId;
import fr.projet.tihic.service.IServiceMove;
import fr.projet.tihic.service.impl.rules.ServiceRules;
import fr.projet.tihic.utils.Utils;
import fr.projet.tihic.wip.WorkInProgress;

public class ServiceMove implements IServiceMove {

	// Use this methode for every pieces
	// Integral permet de récuperer les deplacements en prenant en compte la prise allié.
	// Echec en situation d'echec dégage l'axe d'attaque de la pièce mettant le roi en position d'écheque.
	// Autorize permet de vérifier si le coup est régelementaire. (ne met pas le roi alliée en situation d'echeque.)
	// Pion permet de ne pas prendre en compte les deplacements propre au pion qui ne peuve prendre de piece.(Vertical.)
	@Override
	public List<String> getMove(AbstractPiece piece, Board board, boolean integral, boolean echec,boolean autorize,boolean pion, String pos) {
		switch (piece.getType()) {
		case PieceId.PAWN_LABEL:
			return pawnMove((Pawn) piece, board, integral, echec,autorize, pion, pos);

		case PieceId.ROOK_LABEL:
			return rookMove(piece, board, integral, echec,autorize, pos);

		case PieceId.BISHOP_LABEL:
			return bishopMove(piece, board, integral, echec,autorize, pos);

		case PieceId.QUEEN_LABEL:
			return queenMove((Queen) piece, board, integral, echec,autorize, pos);

		case PieceId.KNIGHT_LABEL:
			return knightMove((Knight) piece, board, integral, echec,autorize, pos);

		case PieceId.KING_LABEL:
			return kingMove((King) piece, board, autorize);

		default:
			return null;
		}
	}

	//Mouvement possible pour le pion
	@Override
	public List<String> pawnMove(Pawn pawn, Board board, boolean integral, boolean echec,boolean autorize, boolean pion, String pos) {
		ServiceRules service = new ServiceRules();
		
		List<String> possiblePath = new ArrayList<String>();
		Map<String, Integer> initialPosition = new HashMap<String, Integer>();
		
		int column = pawn.getPosition().get(PositionId.COLUMN);
		int line = pawn.getPosition().get(PositionId.LINE);
		
		initialPosition.put(PositionId.COLUMN, column);
		initialPosition.put(PositionId.LINE, line);
		
		
		String keyToInit = Utils.getPositionFromCoordinate(initialPosition);
		String keyToCheck;
		List<String> test = new ArrayList<String>();
		boolean verif = true;
		
		String kingPosition = "";
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				if(entry.getValue() instanceof King && entry.getValue().getColor().equals(pawn.getColor()))kingPosition = Utils.getPositionFromCoordinate(entry.getValue().getPosition());
			}
		}

		
		// Premier mouvement
		if(pawn.isFirstMove()) {
			if(board.getChessBoard().get(keyToInit).getColor() == ColorId.COLOR_BLACK) {
				test = new ArrayList<String>();
				verif = true;
				for(int i = 0; i<2 ; i++) {
				
					Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
					
					line--;
				
					possiblePosition.put(PositionId.COLUMN, column);
					possiblePosition.put(PositionId.LINE, line);
				
					keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
					
					test.add(keyToCheck);
					
					if(board.getChessBoard().get(test.get(i)) != null) verif =false;
					if (board.getChessBoard().get(keyToCheck) == null && verif && !pion) {

						if (autorize) {
							if (service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))
								possiblePath.add(keyToCheck);
						} else
							possiblePath.add(keyToCheck);

					}
					
					if(echec) {
						if(integral)possiblePath.add(keyToInit);
						if(service.echecPathRestrict(board, possiblePath, pos)) {
							return possiblePath;
						}
						else possiblePath = new ArrayList<String>();
					}
					
				}
				Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
				
				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				column++;
				line--;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) != null && (board.getChessBoard().get(keyToCheck).getColor() != pawn.getColor() ||  integral) ) {
					if(autorize) {
						if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
					}
					else possiblePath.add(keyToCheck);
				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
				possiblePosition = new HashMap<String, Integer>();
				
				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				column--;
				line--;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) != null && (board.getChessBoard().get(keyToCheck).getColor() != pawn.getColor() || integral) ) {
					if(autorize) {
						if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
					}
					else possiblePath.add(keyToCheck);
				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
			}
			else {
				test = new ArrayList<String>();
				verif = true;
				for(int i = 0; i<2 ; i++) {
					
					Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
					
					line++;
				
					possiblePosition.put(PositionId.COLUMN, column);
					possiblePosition.put(PositionId.LINE, line);
				
					keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
					
					test.add(keyToCheck);
					
					if(board.getChessBoard().get(test.get(i)) != null) verif =false;
					if (board.getChessBoard().get(keyToCheck) == null && verif &&!pion) {

						if (autorize) {
							if (service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))
								possiblePath.add(keyToCheck);
						} else
							possiblePath.add(keyToCheck);

					}
					
					if(echec) {
						if(integral)possiblePath.add(keyToInit);
						if(service.echecPathRestrict(board, possiblePath, pos)) {
							return possiblePath;
						}
						else possiblePath = new ArrayList<String>();
					}
					
				}
				Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
				
				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				column++;
				line++;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) != null && (board.getChessBoard().get(keyToCheck).getColor() != pawn.getColor() || integral) ) {
					if(autorize) {
						if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
					}
					else possiblePath.add(keyToCheck);
				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
				possiblePosition = new HashMap<String, Integer>();
				
				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				column--;
				line++;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) != null && (board.getChessBoard().get(keyToCheck).getColor() != pawn.getColor() || integral) ) {
					if(autorize) {
						if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
					}
					else possiblePath.add(keyToCheck);
				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
			}
		}
		
		else {
			if(board.getChessBoard().get(keyToInit).getColor() == ColorId.COLOR_BLACK) {
				
				Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
				
				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				line--;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) == null && !pion) {

					if (autorize) {
						if (service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))
							possiblePath.add(keyToCheck);
					} else
						possiblePath.add(keyToCheck);

				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
				possiblePosition = new HashMap<String, Integer>();
				

				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				column++;
				line--;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) != null && (board.getChessBoard().get(keyToCheck).getColor() != pawn.getColor() || integral) ) {
					if(autorize) {
						if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
					}
					else possiblePath.add(keyToCheck);
				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
				possiblePosition = new HashMap<String, Integer>();
				

				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				column--;
				line--;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) != null && (board.getChessBoard().get(keyToCheck).getColor() != pawn.getColor() || integral) ) {
					if(autorize) {
						if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
					}
					else possiblePath.add(keyToCheck);
				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
			}
			
			else {
				Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
				
				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				line++;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) == null && !pion) {

					if (autorize) {
						if (service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))
							possiblePath.add(keyToCheck);
					} else
						possiblePath.add(keyToCheck);

				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
				possiblePosition = new HashMap<String, Integer>();
				

				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				column++;
				line++;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) != null && (board.getChessBoard().get(keyToCheck).getColor() != pawn.getColor() || integral) ) {
					if(autorize) {
						if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
					}
					else possiblePath.add(keyToCheck);
				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
				possiblePosition = new HashMap<String, Integer>();
				

				column = pawn.getPosition().get(PositionId.COLUMN);
				line = pawn.getPosition().get(PositionId.LINE);
				
				column--;
				line++;
				
				possiblePosition.put(PositionId.COLUMN, column);
				possiblePosition.put(PositionId.LINE, line);
				
				keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
				
				if (board.getChessBoard().get(keyToCheck) != null && (board.getChessBoard().get(keyToCheck).getColor() != pawn.getColor() || integral) ) {
					if(autorize) {
						if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
					}
					else possiblePath.add(keyToCheck);
				}
				
				if(echec) {
					if(integral)possiblePath.add(keyToInit);
					if(service.echecPathRestrict(board, possiblePath, pos)) {
						return possiblePath;
					}
					else possiblePath = new ArrayList<String>();
				}
				
			}
		}
		
		// Prise en Passant
		if (!pawn.getEnPassant().isEmpty()) {
			for (Map.Entry<String, Integer> entry : pawn.getEnPassant().entrySet()) {
				if (entry.getValue() == (WorkInProgress.getNbcoup_tot() - 1)) {
					Map<String, Integer> position = Utils.getCoordinate(entry.getKey());

					column = position.get(PositionId.COLUMN);
					line = position.get(PositionId.LINE);

					if (board.getChessBoard().get(keyToInit).getColor() == ColorId.COLOR_BLACK) {

						Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
						line--;

						possiblePosition.put(PositionId.COLUMN, column);
						possiblePosition.put(PositionId.LINE, line);

						keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
						if(autorize) {
							if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
						}
						else possiblePath.add(keyToCheck);
					} else {
						Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
						line++;

						possiblePosition.put(PositionId.COLUMN, column);
						possiblePosition.put(PositionId.LINE, line);

						keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
						if(autorize) {
							if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
						}
						else possiblePath.add(keyToCheck);
					}
				}
			}
		}

		return possiblePath;
	}

	
	//Mouvement possible pour la tour
	@Override
	public List<String> rookMove(AbstractPiece rookOrQueen, Board board, boolean integral, boolean echec,boolean autorize, String pos) {
		if (rookOrQueen.getType() != PieceId.ROOK_LABEL) {
			if (rookOrQueen.getType() != PieceId.QUEEN_LABEL) {
				return null;
			}
		}
		
		String kingPosition = "";
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				if(entry.getValue() instanceof King && entry.getValue().getColor().equals(rookOrQueen.getColor()))kingPosition = Utils.getPositionFromCoordinate(entry.getValue().getPosition());
			}
		}
		
		ServiceRules service = new ServiceRules();
		
		Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
		List<String> possiblePath = new ArrayList<>();
		int column = rookOrQueen.getPosition().get(PositionId.COLUMN);
		int line = rookOrQueen.getPosition().get(PositionId.LINE);
		
		possiblePosition.put(PositionId.COLUMN, column);
		possiblePosition.put(PositionId.LINE, line);
		String keyToInit = Utils.getPositionFromCoordinate(possiblePosition);
				
		column++;
		while (column <= 8) {
			
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != rookOrQueen.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
				break;
			} else {
				break;
			}
			column++;
		}
		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}

		column = rookOrQueen.getPosition().get(PositionId.COLUMN) - 1;

		while (column >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != rookOrQueen.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
				break;
			} else {
				break;
			}
			column--;
		}
		
		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		
		column = rookOrQueen.getPosition().get(PositionId.COLUMN);
		line++;
		while (line <= 8) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != rookOrQueen.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
				break;
			} else {
				break;
			}
			line++;
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		line = rookOrQueen.getPosition().get(PositionId.LINE) - 1;

		while (line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != rookOrQueen.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
				break;
			} else {
				break;
			}
			line--;
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		return possiblePath;
	}

	
	//Mouvement possible pour le fou.
	@Override
	public List<String> bishopMove(AbstractPiece bishopOrQueen, Board board, boolean integral, boolean echec,boolean autorize, String pos) {
		
		ServiceRules service = new ServiceRules();
		
		Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
		List<String> possiblePath = new ArrayList<>();
		int column = bishopOrQueen.getPosition().get(PositionId.COLUMN);
		int line = bishopOrQueen.getPosition().get(PositionId.LINE);
		
		possiblePosition.put(PositionId.COLUMN, column);
		possiblePosition.put(PositionId.LINE, line);
		String keyToInit = Utils.getPositionFromCoordinate(possiblePosition);
		
		String kingPosition = "";
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				if(entry.getValue() instanceof King && entry.getValue().getColor().equals(bishopOrQueen.getColor()))kingPosition = Utils.getPositionFromCoordinate(entry.getValue().getPosition());
			}
		}

		// diagonale haut+droite
		column++;
		line++;
		while (column <= 8 && line <= 8) {
			
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != bishopOrQueen.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
				break;
			} else {
				break;
			}
			column++;
			line++;
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		column = bishopOrQueen.getPosition().get(PositionId.COLUMN);
		line = bishopOrQueen.getPosition().get(PositionId.LINE);
		// diagonale haut+gauche
		column--;
		line++;
		while (column >= 1 && line <= 8) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != bishopOrQueen.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
				break;
			} else {
				break;
			}
			column--;
			line++;
		}
		
		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}

		column = bishopOrQueen.getPosition().get(PositionId.COLUMN);
		line = bishopOrQueen.getPosition().get(PositionId.LINE);
		// diagonale bas+gauche
		column--;
		line--;
		while (column >= 1 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != bishopOrQueen.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
				break;
			} else {
				break;
			}
			column--;
			line--;
		}
		
		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}

		column = bishopOrQueen.getPosition().get(PositionId.COLUMN);
		line = bishopOrQueen.getPosition().get(PositionId.LINE);
		// diagonale bas +droite
		column++;
		line--;
		while (column <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != bishopOrQueen.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
				break;
			} else {
				break;
			}
			column++;
			line--;
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		return possiblePath;
	}

	
	//Mouvement possible pour le cavalier.
	@Override
	public List<String> knightMove(Knight knight, Board board, boolean integral, boolean echec,boolean autorize, String pos) {
		
		ServiceRules service = new ServiceRules();
		
		Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
		List<String> possiblePath = new ArrayList<>();
		int column = knight.getPosition().get(PositionId.COLUMN);
		int line = knight.getPosition().get(PositionId.LINE);
		
		
		possiblePosition.put(PositionId.COLUMN, column);
		possiblePosition.put(PositionId.LINE, line);
		String keyToInit = Utils.getPositionFromCoordinate(possiblePosition);
		
		
		String kingPosition = "";
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				if(entry.getValue() instanceof King && entry.getValue().getColor().equals(knight.getColor()))kingPosition = Utils.getPositionFromCoordinate(entry.getValue().getPosition());
			}
		}
		
		// 8 possible moves, up(left/right) /down (left/right) /left(up/down)
		// /right(up/down)

		column = column - 2;
		line++;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != knight.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}
		
		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		column = knight.getPosition().get(PositionId.COLUMN);
		line = knight.getPosition().get(PositionId.LINE);

		column = column + 2;
		line++;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != knight.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		column = knight.getPosition().get(PositionId.COLUMN);
		line = knight.getPosition().get(PositionId.LINE);
		column = column - 2;
		line--;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != knight.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		column = knight.getPosition().get(PositionId.COLUMN);
		line = knight.getPosition().get(PositionId.LINE);
		column = column + 2;
		line--;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != knight.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		column = knight.getPosition().get(PositionId.COLUMN);
		line = knight.getPosition().get(PositionId.LINE);
		column++;
		line = line - 2;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != knight.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		column = knight.getPosition().get(PositionId.COLUMN);
		line = knight.getPosition().get(PositionId.LINE);
		column--;
		line = line - 2;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != knight.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}
		
		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		column = knight.getPosition().get(PositionId.COLUMN);
		line = knight.getPosition().get(PositionId.LINE);
		column++;
		line = line + 2;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != knight.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}

		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		column = knight.getPosition().get(PositionId.COLUMN);
		line = knight.getPosition().get(PositionId.LINE);
		column--;
		line = line + 2;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != knight.getColor() || integral) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}
		
		if(echec) {
			if(integral)possiblePath.add(keyToInit);
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}

		return possiblePath;
	}

	
	//Mouvement possible pour la reine.
	@Override
	public List<String> queenMove(Queen queen, Board board, boolean integral, boolean echec,boolean autorize, String pos) {
		ServiceRules service = new ServiceRules();
		
		List<String> possiblePath = new ArrayList<>();
		int column = queen.getPosition().get(PositionId.COLUMN);
		int line = queen.getPosition().get(PositionId.LINE);
		
		possiblePath.addAll(rookMove(queen, board, integral, echec,autorize, pos));
		
		if(echec) {
			if(service.echecPathRestrict(board, possiblePath, pos)) {
				return possiblePath;
			}
			else possiblePath = new ArrayList<String>();
		}
		
		possiblePath.addAll(bishopMove(queen, board, integral, echec,autorize, pos));
		return possiblePath;
	}

	
	//Mouvement possible pour le roi.
	@Override
	public List<String> kingMove(King king, Board board, boolean autorize) {
		List<String> possiblePath = new ArrayList<>();
		int column = king.getPosition().get(PositionId.COLUMN);
		int line = king.getPosition().get(PositionId.LINE);
		ServiceRules service = new ServiceRules();
		Map<String, Integer> possiblePosition = new HashMap<String, Integer>();
		
		possiblePosition.put(PositionId.COLUMN, column);
		possiblePosition.put(PositionId.LINE, line);
		String keyToInit = Utils.getPositionFromCoordinate(possiblePosition);
		
		String kingPosition = "";
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				if(entry.getValue() instanceof King && entry.getValue().getColor().equals(king.getColor()))kingPosition = Utils.getPositionFromCoordinate(entry.getValue().getPosition());
			}
		}
		
		column++;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != king.getColor()) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}

		line--;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != king.getColor()) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}
		
		column--;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != king.getColor()) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}
		
		column--;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != king.getColor()) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}
		
		line++;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != king.getColor()) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}
		
		line++;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != king.getColor()) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}
		
		column++;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);

			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != king.getColor()) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
		}

		column++;
		if (column <= 8 && column >= 1 && line <= 8 && line >= 1) {
			possiblePosition = new HashMap<String, Integer>();
			possiblePosition.put(PositionId.COLUMN, column);
			possiblePosition.put(PositionId.LINE, line);
			String keyToCheck = Utils.getPositionFromCoordinate(possiblePosition);
			
			
			if (board.getChessBoard().get(keyToCheck) == null) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			} else if (board.getChessBoard().get(keyToCheck).getColor() != king.getColor()) {
				if(autorize) {
					if(service.autoeizedPath(board, keyToInit, keyToCheck, kingPosition))possiblePath.add(keyToCheck);
				}
				else possiblePath.add(keyToCheck);
			}
			
		}
		return possiblePath;
	}

}
