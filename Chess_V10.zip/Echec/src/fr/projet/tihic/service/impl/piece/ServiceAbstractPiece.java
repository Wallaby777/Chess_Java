package fr.projet.tihic.service.impl.piece;

import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.Bishop;
import fr.projet.tihic.piece.King;
import fr.projet.tihic.piece.Knight;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Queen;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.reference.ColorId;
import fr.projet.tihic.reference.PieceId;
import fr.projet.tihic.service.IServiceAbstractPiece;

public class ServiceAbstractPiece implements IServiceAbstractPiece {

	@Override
	public AbstractPiece get(String reference) {
		// Not used
		return null;
	}

	@Override
	public AbstractPiece create() {
		// Not used
		return null;
	}

	// TODO add player to parametter for select the piece color and give the uuid to
	// the player to give him the controle of the piece
	@Override
	public AbstractPiece create(String pieceType, String color) {

		if (color.equals(ColorId.COLOR_BLACK)) {
			switch (pieceType) {
			case PieceId.PAWN_LABEL:
				Pawn pawn = new Pawn();
				pawn.setFirstMove(true);
				pawn.setValueForIA(-10);
				pawn.setType(pieceType);
				pawn.setColor(color);
				pawn.setValueMove(0);
				return pawn;

			case PieceId.ROOK_LABEL:
				Rook rook = new Rook();
				rook.setIsFirstMove(true);
				rook.setValueForIA(-50);
				rook.setType(pieceType);
				rook.setColor(color);
				rook.setValueMove(0);
				return rook;

			case PieceId.BISHOP_LABEL:
				Bishop bishop = new Bishop();
				bishop.setValueForIA(-30);
				bishop.setType(pieceType);
				bishop.setColor(color);
				bishop.setValueMove(0);
				return bishop;

			case PieceId.KING_LABEL:
				King king = new King();
				king.setFirstMove(true);
				king.setValueForIA(-900);
				king.setType(pieceType);
				king.setColor(color);
				king.setValueMove(0);
				return king;

			case PieceId.KNIGHT_LABEL:
				Knight knight = new Knight();
				knight.setValueForIA(-30);
				knight.setType(pieceType);
				knight.setColor(color);
				knight.setValueMove(0);
				return knight;

			case PieceId.QUEEN_LABEL:
				Queen queen = new Queen();
				queen.setValueForIA(-90);
				queen.setType(pieceType);
				queen.setColor(color);
				queen.setValueMove(0);
				return queen;

			default:
				return null;
			}
		}
		else {
			switch (pieceType) {
			case PieceId.PAWN_LABEL:
				Pawn pawn = new Pawn();
				pawn.setFirstMove(true);
				pawn.setValueForIA(10);
				pawn.setType(pieceType);
				pawn.setColor(color);
				pawn.setValueMove(0);
				return pawn;

			case PieceId.ROOK_LABEL:
				Rook rook = new Rook();
				rook.setIsFirstMove(true);
				rook.setValueForIA(50);
				rook.setType(pieceType);
				rook.setColor(color);
				rook.setValueMove(0);
				return rook;

			case PieceId.BISHOP_LABEL:
				Bishop bishop = new Bishop();
				bishop.setValueForIA(30);
				bishop.setType(pieceType);
				bishop.setColor(color);
				bishop.setValueMove(0);
				return bishop;

			case PieceId.KING_LABEL:
				King king = new King();
				king.setFirstMove(true);
				king.setValueForIA(900);
				king.setType(pieceType);
				king.setColor(color);
				king.setValueMove(0);
				return king;

			case PieceId.KNIGHT_LABEL:
				Knight knight = new Knight();
				knight.setValueForIA(30);
				knight.setType(pieceType);
				knight.setColor(color);
				knight.setValueMove(0);
				return knight;

			case PieceId.QUEEN_LABEL:
				Queen queen = new Queen();
				queen.setValueForIA(90);
				queen.setType(pieceType);
				queen.setColor(color);
				queen.setValueMove(0);
				return queen;

			default:
				return null;
			}
		}

	}
}