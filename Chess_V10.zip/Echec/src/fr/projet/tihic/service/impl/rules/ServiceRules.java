package fr.projet.tihic.service.impl.rules;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.swing.ImageIcon;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.interfa.Game;
import fr.projet.tihic.interfa.Promotion;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.King;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.player.Player;
import fr.projet.tihic.reference.ColorId;
import fr.projet.tihic.reference.PieceId;
import fr.projet.tihic.reference.PositionId;
import fr.projet.tihic.service.IServiceRules;
import fr.projet.tihic.service.impl.move.ServiceMove;
import fr.projet.tihic.service.impl.piece.ServiceAbstractPiece;
import fr.projet.tihic.utils.Utils;
import fr.projet.tihic.wip.WorkInProgress;

public class ServiceRules implements IServiceRules {

	
	//Méthode vérifiant la situation de promotion effective auquel cas appelle du JDialog promotion modulaire de l'interface Game.
	@Override
	public Promotion promotion(Board board, Player player, WorkInProgress work, Game game) {
		
		List<String> possible = new ArrayList<String>();
		List<String> keys = new ArrayList<String>();
		String cas;
		
		if(player.getColor() == ColorId.COLOR_WHITE) {
			possible.add("A8");possible.add("B8");possible.add("C8");possible.add("D8");possible.add("E8");possible.add("F8");possible.add("G8");possible.add("H8");
		}
		else {
			possible.add("A1");possible.add("B1");possible.add("C1");possible.add("D1");possible.add("E1");possible.add("F1");possible.add("G1");possible.add("H1");
		}
		for(int i=0;i<possible.size();i++) {
			if(board.getChessBoard().get(possible.get(i)) instanceof Pawn) {
				Pawn pawn = (Pawn)board.getChessBoard().get(possible.get(i));
				if (pawn.getColor() == player.getColor()) {
					if (!player.isIA()) {
						cas = possible.get(i);
						return new Promotion(board, player, cas, work, game);
					}
					else {
						ServiceAbstractPiece serviceAbstractPiece = new ServiceAbstractPiece();
						
						cas = possible.get(i);
						
						for(Map.Entry<String, ImageIcon> entry : work.getImagePromotionIa().entrySet()) {
							keys.add(entry.getKey());
						}
						
						String imagePro = keys.get(((int) Math.random() * (keys.size()-1)));
						
						board.getChessBoard().put(cas,serviceAbstractPiece.create(imagePro, ColorId.COLOR_BLACK));						
						Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), work.getImagePromotionIa().get(imagePro));
						Game.setImage(cas, work.getImagePromotionIa().get(imagePro));
						board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
						Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());
						
					}
				}
			}
		}
		
		return null;
	}
	
	
	//Retourne la liste des positions spécifique au roque possible si les conditions sont remplie.
	@Override
	public List<String> castling(Board board, String ride) {
		
		List<String> position = new ArrayList<String>();
		String arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8;
		
		
		if(ride.equals(ColorId.COLOR_WHITE)) {
			arg1="B1"; arg2="C1"; arg3="D1"; arg4="F1"; arg5="G1"; arg6="E1"; arg7="A1"; arg8="H1";
		}
		else {
			arg1="B8"; arg2="C8"; arg3="D8"; arg4="F8"; arg5="G8"; arg6="E8"; arg7="A8"; arg8="H8";
		}
		
		
		if(board.getChessBoard().get(arg1) == null && board.getChessBoard().get(arg2) == null && board.getChessBoard().get(arg3) == null) {
			if(board.getChessBoard().get(arg6) instanceof King && board.getChessBoard().get(arg7) instanceof Rook) {
				King king = (King)board.getChessBoard().get(arg6);
				Rook rook = (Rook)board.getChessBoard().get(arg7);
				if(king.isFirstMove() && rook.getFirstMove()) {
					position.add(arg2);
				}
			}
		}
		if(board.getChessBoard().get(arg4) == null && board.getChessBoard().get(arg5) == null) {
			if(board.getChessBoard().get(arg6) instanceof King && board.getChessBoard().get(arg8) instanceof Rook) {
				King king = (King)board.getChessBoard().get(arg6);
				Rook rook = (Rook)board.getChessBoard().get(arg8);
				if(king.isFirstMove() && rook.getFirstMove()) {
					position.add(arg5);
				}
			}
		}
		if(position.isEmpty()) {
			position.add(null);
			position.add(null);
			return position;
		}
		else {
			if(position.size() == 1) position.add(null);
			if(position.size() == 2) return position;
		}
		return position;
	}

	
	//Evolution du plateau de jeux si un coup de type roque à était effectué.
	@Override
	public void castlingProgress(Board chessBoard, String posFin, String ride) {
		if (chessBoard.getChessBoard().get(posFin) instanceof King) {
			King king = (King) chessBoard.getChessBoard().get(posFin);
			if (king.isFirstMove()) {
				king.setFirstMove(false);

				if (ride == ColorId.COLOR_WHITE) {

					if (posFin.equals("C1")) {
						Game.setListeDeCase((Utils.getCoordinate("D1").get(PositionId.LINE) - 1), (Utils
								.getCoordinate("D1").get(PositionId.COLUMN) - 1), Game.getImage().get("A1"));
						Game.setListeDeCase((Utils.getCoordinate("A1").get(PositionId.LINE) - 1),(Utils
								.getCoordinate("A1").get(PositionId.COLUMN) - 1), null);

						Game.setImage("D1", Game.getImage().get("A1"));
						Game.setImage("A1", null);

						chessBoard.getChessBoard().put("D1", chessBoard.getChessBoard().get("A1"));
						chessBoard.getChessBoard().put("A1", null);
						chessBoard.getChessBoard().get("D1").setPosition(Utils.getCoordinate("D1"));

						if (chessBoard.getChessBoard().get("D1") instanceof Rook) {
							Rook rook = (Rook) chessBoard.getChessBoard().get("D1");
							rook.setIsFirstMove(false);
						}
					} else if (posFin.equals("G1")) {
						Game.setListeDeCase((Utils.getCoordinate("F1").get(PositionId.LINE) - 1), (Utils
								.getCoordinate("F1").get(PositionId.COLUMN) - 1), Game.getImage().get("H1"));
						Game.setListeDeCase((Utils.getCoordinate("H1").get(PositionId.LINE) - 1),(Utils
								.getCoordinate("H1").get(PositionId.COLUMN) - 1), null);

						Game.setImage("F1", Game.getImage().get("H1"));
						Game.setImage("H1", null);
						

						chessBoard.getChessBoard().put("F1", chessBoard.getChessBoard().get("H1"));
						chessBoard.getChessBoard().put("H1", null);
						chessBoard.getChessBoard().get("F1").setPosition(Utils.getCoordinate("F1"));
						
						if (chessBoard.getChessBoard().get("F1") instanceof Rook) {
							Rook rook = (Rook) chessBoard.getChessBoard().get("F1");
							rook.setIsFirstMove(false);
						}
					}
				} else {
					if (posFin.equals("C8")) {

						
						Game.setListeDeCase((Utils.getCoordinate("D8").get(PositionId.LINE) - 1), (Utils
								.getCoordinate("D8").get(PositionId.COLUMN) - 1), Game.getImage().get("A8"));
						Game.setListeDeCase((Utils.getCoordinate("A8").get(PositionId.LINE) - 1),(Utils
								.getCoordinate("A8").get(PositionId.COLUMN) - 1), null);

						Game.setImage("D8", Game.getImage().get("A8"));
						Game.setImage("A8", null);
						

						chessBoard.getChessBoard().put("D8", chessBoard.getChessBoard().get("A8"));
						chessBoard.getChessBoard().put("A8", null);
						chessBoard.getChessBoard().get("D8").setPosition(Utils.getCoordinate("D8"));
						
						if (chessBoard.getChessBoard().get("D8") instanceof Rook) {
							Rook rook = (Rook) chessBoard.getChessBoard().get("D8");
							rook.setIsFirstMove(false);
						}

					} else if (posFin.equals("G8")) {
						
						
						Game.setListeDeCase((Utils.getCoordinate("F8").get(PositionId.LINE) - 1), (Utils
								.getCoordinate("F8").get(PositionId.COLUMN) - 1), Game.getImage().get("H8"));
						Game.setListeDeCase((Utils.getCoordinate("H8").get(PositionId.LINE) - 1),(Utils
								.getCoordinate("H8").get(PositionId.COLUMN) - 1), null);

						Game.setImage("F8", Game.getImage().get("H8"));
						Game.setImage("H8", null);

						chessBoard.getChessBoard().put("F8", chessBoard.getChessBoard().get("H8"));
						chessBoard.getChessBoard().put("H8", null);
						chessBoard.getChessBoard().get("F8").setPosition(Utils.getCoordinate("F8"));

						if (chessBoard.getChessBoard().get("F8") instanceof Rook) {
							Rook rook = (Rook) chessBoard.getChessBoard().get("F8");
							rook.setIsFirstMove(false);
						}
					}
				}
			}
		}
		
	}
	
	
	//Evaluation de la position et des différentes condition nécessaire à la prise en passant 
	//pour auquel cas updater la Map enPassant du pion; pouvant effectuer ce mouvement au prochain tour.
	@Override
	public void enPassant(Board board, String start, String end, WorkInProgress work) {
		
		if(board.getChessBoard().get(end) instanceof Pawn) {
			Pawn pawn = (Pawn)board.getChessBoard().get(end);
			if(pawn.isFirstMove()) {
				Map<String, Integer> initialPosition = new HashMap<String, Integer>();
				
				int column = pawn.getPosition().get(PositionId.COLUMN);
				int line = pawn.getPosition().get(PositionId.LINE);
				
				
				if(Math.abs((Utils.getCoordinate(end).get(PositionId.LINE))-(Utils.getCoordinate(start).get(PositionId.LINE))) == 2){
					initialPosition.put(PositionId.COLUMN, (column-1));
					initialPosition.put(PositionId.LINE, line);
					String keyToInit = Utils.getPositionFromCoordinate(initialPosition);
					
					if (board.getChessBoard().get(keyToInit) instanceof Pawn) {
						if (!board.getChessBoard().get(keyToInit).getColor()
								.equals(board.getChessBoard().get(end).getColor())) {

							Pawn pawn1 = (Pawn) board.getChessBoard().get(keyToInit);
							pawn1.setEnPassant(end, WorkInProgress.getNbcoup_tot());
							
						}
					}
					
					initialPosition.put(PositionId.COLUMN, (column+1));
					initialPosition.put(PositionId.LINE, line);
					keyToInit = Utils.getPositionFromCoordinate(initialPosition);
					
					if (board.getChessBoard().get(keyToInit) instanceof Pawn) {
						if (!board.getChessBoard().get(keyToInit).getColor()
								.equals(board.getChessBoard().get(end).getColor())) {

							Pawn pawn1 = (Pawn) board.getChessBoard().get(keyToInit);
							pawn1.setEnPassant(end, WorkInProgress.getNbcoup_tot());
							
						}
					}
				}
				pawn.setFirstMove(false);
			}
		}
	}

	
	//Vérification du plateau de jeu pour établir l'état, echec ou non.
	@Override
	public boolean echecCheck(Board board, ServiceMove service, String color) {
		boolean echec = false;
		List<String> possibleMove = new ArrayList<String>();
		String kingposition = "";
		
		service = new ServiceMove();
		
		
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				
				if(entry.getValue().getColor().equals(color))possibleMove.addAll(service.getMove(entry.getValue(), board, true, false, false, false, null));
				
				if(entry.getValue() instanceof King && !entry.getValue().getColor().equals(color))kingposition = Utils.getPositionFromCoordinate(entry.getValue().getPosition());
				
			}
		}
		
		if(possibleMove != null) {
			for(int i=0; i<possibleMove.size(); i++) {
				if(kingposition.equals(possibleMove.get(i)))echec=true;
			}
		}
		
		return echec;
	}

	//Si la condition d'echec est vrai alors on dégage la piece mettant en echec le roi.
	@Override
	public  List<AbstractPiece> echecPiece(Board board, ServiceMove service, String color) {
		
		List<String> possibleMove = new ArrayList<String>();
		List<AbstractPiece> piece = new ArrayList<AbstractPiece>();
		
		String kingposition = "";
		service = new ServiceMove();
		
		
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				
				if(entry.getValue().getColor().equals(color)) {
					possibleMove=service.getMove(entry.getValue(), board, true, false, false, false, null);
					entry.getValue().setPossiblePath(possibleMove);
				}
				if(entry.getValue() instanceof King && !entry.getValue().getColor().equals(color))kingposition = Utils.getPositionFromCoordinate(entry.getValue().getPosition());
				
			}
		}
		
		for(Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if(entry.getValue() != null) {
				if(entry.getValue().getColor().equals(color)) {
					//Utils.getPositionFromCoordinate(entry.getValue().getPosition()).equals
					for(int i = 0; i<entry.getValue().getPossiblePath().size(); i++) {
						if(entry.getValue().getPossiblePath().get(i).equals(kingposition)) {
							entry.getValue().setPossiblePath(service.getMove(entry.getValue(), board, true, true, false, false, kingposition));
							piece.add(entry.getValue());
						}
					}
				}
			}
		}
		
		return piece;
	}
	
	
	//Retourne une liste de coup possible pour la situation d'echec.
	@Override
	public List<String> echecPath(Board board, ServiceMove service, String color) {
		
		List<String> possibleMove = new ArrayList<String>();
		
		
		service = new ServiceMove();
		
		
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {

				if (entry.getValue().getColor().equals(color)
						&& !entry.getValue().getType().equals(PieceId.KING_LABEL)) {
					possibleMove.addAll(service.getMove(entry.getValue(), board, true, false, false, true, null));
				}
			}
		}
		
		
		
		
		return possibleMove;
	}
	
	
	//Retourne la piece correspondant au Roi qui est en situation d'echec.
	@Override
	public AbstractPiece echecKing(Board board, ServiceMove service, String color) {
		
		service = new ServiceMove();
		
		
		for (Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if (entry.getValue() != null) {
				
				if(entry.getValue() instanceof King && !entry.getValue().getColor().equals(color)) return entry.getValue();
				
			}
		}
		
		
		return null;
	}
	
	//Permet l'extraction de l'angle d'attaque de la piece mettant le roi en echec. Méthode appeller dans le ServiceMove
	@Override
	public boolean echecPathRestrict(Board board, List<String> move, String position) {
		String kingPosition;
		
		kingPosition = Utils.getPositionFromCoordinate(board.getChessBoard().get(position).getPosition());
		for(int i = 0; i<move.size(); i++) {
			if(move.get(i).equals(kingPosition))return true;
		}
		return false;
	}
	
	//Vérifie si le mouvement est autorisé, c'est à dire ne met pas en echec le roi allié.
	@Override
	public boolean autoeizedPath(Board board, String keytoinit, String possibleMove, String kingPosition) {
		
		Board boardCl = new Board();
		ServiceMove service = new ServiceMove();
		ServiceAbstractPiece serviceAbstractPiece = new ServiceAbstractPiece();
		Map<String, AbstractPiece> boardClone = new HashMap<String, AbstractPiece>();
		List<String> possiblePath = new ArrayList<String>();
		
		for(Map.Entry<String, AbstractPiece> entry : board.getChessBoard().entrySet()) {
			if(entry.getValue() != null)
			boardClone.put(entry.getKey(), serviceAbstractPiece.create(entry.getValue().getType(), entry.getValue().getColor()) );
			else boardClone.put(entry.getKey(), null ); ; 
		}
		
		boardClone.put(possibleMove, boardClone.get(keytoinit));
		boardClone.put(keytoinit, null);
		
		Set<String> keys = boardClone.keySet();
		for (String key : keys) {
			if (boardClone.get(key) != null) {
				boardClone.get(key).setPosition(Utils.getCoordinate(key));
			}
		}
		
		boardCl.setChessBoard(boardClone);
		
		for(Map.Entry<String, AbstractPiece> entry : boardCl.getChessBoard().entrySet()) {
			if(entry.getValue() != null) {
				if (!entry.getValue().getColor().equals(board.getChessBoard().get(keytoinit).getColor())) {
					possiblePath.addAll(service.getMove(entry.getValue(), boardCl, false, false, false, true, null));
				}
			}
		}
		
		if (board.getChessBoard().get(keytoinit) instanceof King) {
			for (int i = 0; i < possiblePath.size(); i++) {
				if (possibleMove.equals(possiblePath.get(i)))
					return false;
			}
		} else {
			for (int i = 0; i < possiblePath.size(); i++) {
				if (kingPosition.equals(possiblePath.get(i)))
					return false;
			}
		}
		
		return true;
	}

	//Vérification si situation d'echec il y a, si le mat est effectif.
	@Override
	public List<AbstractPiece> echecMat(String ride, ServiceMove service, Board chessBoard, WorkInProgress work, List<AbstractPiece> chaud) {
		
		List<String> possiblepath = new ArrayList<String>();
		List<String> complique = new ArrayList<String>();
		List<String> complique2 = new ArrayList<String>();
		chaud = new ArrayList<AbstractPiece>();
		
		
		if (ride == ColorId.COLOR_WHITE) {

			if(echecCheck(chessBoard, service, work.getPlayer().get(0).getColor())) {
				chaud = new ArrayList<AbstractPiece>();
				possiblepath = service.getMove(echecKing(chessBoard, service, work.getPlayer().get(0).getColor()), chessBoard, false, false, true, false, null);
				
				for(int i = 0; i<echecPath(chessBoard, service, work.getPlayer().get(0).getColor()).size(); i++) {
					for(int j = 0; j < possiblepath.size(); j++) {
						if(echecPath(chessBoard, service, work.getPlayer().get(0).getColor()).get(i).equals(possiblepath.get(j))) {
							possiblepath.remove(j);
						}
					}
				}
				if(!possiblepath.isEmpty()) {
					echecKing(chessBoard, service, work.getPlayer().get(0).getColor()).setPossiblePath(possiblepath);
					chaud.add(echecKing(chessBoard, service, work.getPlayer().get(0).getColor()));
				}
				
				
				for (Map.Entry<String, AbstractPiece> entry : chessBoard.getChessBoard().entrySet()) {
					if (entry.getValue() != null) {
						if (entry.getValue().getColor().equals(work.getPlayer().get(1).getColor())
								&& !entry.getValue().getType().equals(PieceId.KING_LABEL)) {
							complique = service.getMove(entry.getValue(), chessBoard, false, false, false,false, null);
							for (int i = 0; i < echecPiece(chessBoard, service, ColorId.COLOR_WHITE)
									.get(0).getPossiblePath().size(); i++) {
								for (int j = 0; j < complique.size(); j++) {
									if (complique.get(j)
											.equals(echecPiece(chessBoard, service, ColorId.COLOR_WHITE).get(0).getPossiblePath().get(i))) {
										complique2.add(complique.get(j));
									}
								}
							}
							if (!complique2.isEmpty()) {
								entry.getValue().setPossiblePath(complique2);
								chaud.add(entry.getValue());
								complique2 = new ArrayList<String>();
							}

						}
					}
				}
			
			}
			
		} else {
			

			if(echecCheck(chessBoard, service, work.getPlayer().get(1).getColor())) {
				chaud = new ArrayList<AbstractPiece>();
				possiblepath = service.getMove(echecKing(chessBoard, service, work.getPlayer().get(1).getColor()), chessBoard, false,false, true,false, null);
				
				for(int i = 0; i<echecPath(chessBoard, service, work.getPlayer().get(1).getColor()).size(); i++) {
					for(int j = 0; j < possiblepath.size(); j++) {
						if(echecPath(chessBoard, service, work.getPlayer().get(1).getColor()).get(i).equals(possiblepath.get(j))) {
							possiblepath.remove(j);
						}
					}
				}
				if(!possiblepath.isEmpty()) {
					echecKing(chessBoard, service, work.getPlayer().get(1).getColor()).setPossiblePath(possiblepath);
					chaud.add(echecKing(chessBoard, service, work.getPlayer().get(1).getColor()));
					
				}						
				for (Map.Entry<String, AbstractPiece> entry : chessBoard.getChessBoard().entrySet()) {
					if (entry.getValue() != null) {
						if (entry.getValue().getColor().equals(work.getPlayer().get(0).getColor())
								&& !entry.getValue().getType().equals(PieceId.KING_LABEL)) {
							complique = service.getMove(entry.getValue(), chessBoard, false, false, false,false, null);
							for (int i = 0; i < echecPiece(chessBoard, service, ColorId.COLOR_BLACK)
									.get(0).getPossiblePath().size(); i++) {
								for (int j = 0; j < complique.size(); j++) {
									if (complique.get(j)
											.equals(echecPiece(chessBoard, service, ColorId.COLOR_BLACK).get(0).getPossiblePath().get(i))) {
										complique2.add(complique.get(j));
									}
								}
							}
							if (!complique2.isEmpty()) {
								entry.getValue().setPossiblePath(complique2);
								chaud.add(entry.getValue());
								complique2 = new ArrayList<String>();
							}

						}
					}
				}
			}

		}
		return chaud;
	}

}
