package fr.projet.tihic.service;

import fr.projet.tihic.board.Board;

public interface IServiceBoard extends IServiceCrud<Board>
{
	public Board create();

}
