package fr.projet.tihic.piece;

import java.util.*;

public abstract class AbstractPiece {

	protected List<String> possiblePath;
	protected String color;
	protected String type;
	protected Map<String, Integer> position;
	protected int valueForIA;
	protected int valueMove;


	public AbstractPiece() {
		super();
	}

	public int getValueMove() {
		return valueMove;
	}

	public void setValueMove(int valueMove) {
		this.valueMove = valueMove;
	}

	
	public List<String> getPossiblePath() {
		return possiblePath;
	}

	public void setPossiblePath(List<String> possiblePath) {
		this.possiblePath = possiblePath;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getValueForIA() {
		return valueForIA;
	}

	public void setValueForIA(int valueForIA) {
		this.valueForIA = valueForIA;
	}

	public Map<String, Integer> getPosition() {
		return position;
	}

	public void setPosition(Map<String, Integer> position) {
		this.position = position;
	}

}
