package fr.projet.tihic.piece;

public class King extends AbstractPiece {

	private boolean check;
	private boolean isFirstMove;

	public King() {
		super();
	}

	public boolean isCheck() {
		return check;
	}

	public void setCheck(boolean check) {
		this.check = check;
	}

	public boolean isFirstMove() {
		return isFirstMove;
	}

	public void setFirstMove(boolean isFirstMove) {
		this.isFirstMove = isFirstMove;
	}
}
