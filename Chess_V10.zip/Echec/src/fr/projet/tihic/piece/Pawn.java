package fr.projet.tihic.piece;


import java.util.*;


public class Pawn extends AbstractPiece {

	private boolean firstMove;
	private HashMap<String,Integer> enPassant;

	public Pawn() {
		super();
		enPassant = new HashMap<String, Integer>();

	}

	public boolean isFirstMove() {
		return firstMove;
	}

	public void setFirstMove(boolean firstMove) {
		this.firstMove = firstMove;
	}


	public HashMap<String,Integer> getEnPassant(){
		return enPassant;
	}
 
	public void setEnPassant(String i, int j) {
		enPassant.put(i, j);
	}

}
