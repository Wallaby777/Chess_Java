package fr.projet.tihic.piece;

public class Knight  extends AbstractPiece
{
	public Knight()
    {
        super();
    }

}
