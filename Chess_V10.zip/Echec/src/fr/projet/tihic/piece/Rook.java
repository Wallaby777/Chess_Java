package fr.projet.tihic.piece;

public class Rook extends AbstractPiece {

	private boolean isFirstMove;

	public Rook() {
		super();
	}

	
	public void setIsFirstMove(boolean First) {
		this.isFirstMove = First;
		
	}

	public boolean getFirstMove() {
		return isFirstMove;
	}



}
