package fr.projet.tihic.piece;

public class Bishop  extends AbstractPiece
{
	public Bishop()
    {
        super();
    }

}
