package fr.projet.tihic.piece;

public class Queen extends AbstractPiece {
	
	public Queen() {
		super();
	}

}
