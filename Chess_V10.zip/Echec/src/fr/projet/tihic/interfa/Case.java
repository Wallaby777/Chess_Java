package fr.projet.tihic.interfa;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JButton;


public class Case extends JButton{
	boolean select;
	boolean possible;
	ImageIcon image;
 //setBackground pour mettre en vert
	
	
	//d�clare attributs
	
	//doit d�clarer couleur de fond, et faire si selectionn� ou non (mettre en vert)
	
	//paintcomponent
	Color couleurDeFond;

	public Case(String a, Color c) {
		// TODO Auto-generated constructor stub
		super(a);
		setBackground(c);
		select=false;
		possible=false;
	}
	
	public Case(ImageIcon i, Color c) {
		// TODO Auto-generated constructor stub
		super();
		setIcon(i);
		image = i;
		setBackground(c);
		select=false;
		possible=false;
	}
	
	public Case(Color c) {
		// TODO Auto-generated constructor stub
		super();
		setBackground(c);
		select=false;
		possible=false;
	}
	//d�finit m�thode avec bool�en, si vraie dans ce cas l� ligne illumin�
	public void setHighlight(Boolean b) {
		possible=b;
		repaint();
	}
	
	public void setPossibleHighlight(Boolean c) {
		select=c;
		repaint();
	}
	
	
	public ImageIcon getImage() {
		return image;
	}

	public void setImage(ImageIcon image) {
		this.image = image;
		setIcon(image);
	}

	public void paintComponent(Graphics g) {
		// Appel de la m�thode paintComponent de la classe m�re
		super.paintComponent(g);
		//setBackground(Color.Case);
		//
		if(select) //si select = true
		{
		//TODO si boolean est true alors highlight la case
		//r�cup�re la dimension du JButton
		Dimension d = getSize(); 
		//d�finit la couleur
		g.setColor(new Color(0,0,255,75));
		//dessine un rectangle � l'int�rieur 
		g.fillRect(5, 5, d.width-10, d.height-10); 
		}
		
		if(possible){
			// TODO si boolean est true alors highlight la case
			// r�cup�re la dimension du JButton
			Dimension d = getSize();
			// d�finit la couleur
			g.setColor(new Color(0, 255, 0,125));
			// dessine un rectangle � l'int�rieur
			g.fillRect(5, 5, d.width - 10, d.height - 10);
			
		}
	}
	
	
}
