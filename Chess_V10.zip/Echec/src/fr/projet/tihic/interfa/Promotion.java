package fr.projet.tihic.interfa;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageProducer;
import java.io.IOException;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.player.Player;
import fr.projet.tihic.reference.ColorId;
import fr.projet.tihic.reference.PieceId;
import fr.projet.tihic.reference.PositionId;
import fr.projet.tihic.service.impl.piece.ServiceAbstractPiece;
import fr.projet.tihic.service.impl.player.ServicePlayer;
import fr.projet.tihic.utils.Utils;
import fr.projet.tihic.wip.WorkInProgress;

public class Promotion extends JDialog {
	
	Case[][] listeDeCase;
	Map<String, ImageIcon> imagePromotion;
	
	//JDialog modulaire de la classe Game permetant Le choix de la piece apres promotion et l'update de l'echiquier et du board.
	public Promotion(Board board, Player player, String cas, WorkInProgress work, Game game) {
		super(game, "Promotion", true);
		
		ServiceAbstractPiece serviceAbstractPiece = new ServiceAbstractPiece();
		
		imagePromotion = work.getImagePromotion();
		
		setLayout(new GridLayout(1,4));
		
		JButton but1 = new JButton();
		JButton but2 = new JButton();
		JButton but3 = new JButton();
		JButton but4 = new JButton();
		
		Image img, img1, img2, img3;
		
		if(player.getColor() == ColorId.COLOR_BLACK) {
			try {
				img = ImageIO.read(getClass().getResource("Black_Knight.png"));
				img = img.getScaledInstance(75, -1, Image.SCALE_DEFAULT);
				img1 = ImageIO.read(getClass().getResource("Black_Bishop.png"));
				img1 = img1.getScaledInstance(75, -1, Image.SCALE_DEFAULT);
				img2 = ImageIO.read(getClass().getResource("Black_Queen.png"));
				img2 = img2.getScaledInstance(75, -1, Image.SCALE_DEFAULT);
				img3 = ImageIO.read(getClass().getResource("Black_Rook.png"));
				img3 = img3.getScaledInstance(75, -1, Image.SCALE_DEFAULT);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				img=null; img1=null; img2=null; img3=null;
				e.printStackTrace();
			}
			but1.setIcon(new ImageIcon(img)); but2.setIcon(new ImageIcon(img1)); but3.setIcon(new ImageIcon(img2)); but4.setIcon(new ImageIcon(img3));
			add(but1); add(but2); add(but3); add(but4);
			
			but1.addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					board.getChessBoard().put(cas,serviceAbstractPiece.create(PieceId.KNIGHT_LABEL, ColorId.COLOR_BLACK));
					
					Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), imagePromotion.get(PieceId.BLACK_KNIGHT_LABEL));
					Game.setImage(cas, imagePromotion.get(PieceId.BLACK_KNIGHT_LABEL));
					board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
					Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());

					
					dispose();
				}
			});
			
			but2.addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					board.getChessBoard().put(cas,serviceAbstractPiece.create(PieceId.BISHOP_LABEL, ColorId.COLOR_BLACK));
					
					Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), imagePromotion.get(PieceId.BLACK_BISHOP_LABEL));
					Game.setImage(cas, imagePromotion.get(PieceId.BLACK_BISHOP_LABEL));
					board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
					Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());

					
					dispose();
				}
			});
			
			but3.addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					board.getChessBoard().put(cas,serviceAbstractPiece.create(PieceId.QUEEN_LABEL, ColorId.COLOR_BLACK));

					Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), imagePromotion.get(PieceId.BLACK_QUEEN_LABEL));
					Game.setImage(cas, imagePromotion.get(PieceId.BLACK_QUEEN_LABEL));
					board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
					Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());
					
					
					dispose();
				}
			});
			
			but4.addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					board.getChessBoard().put(cas,serviceAbstractPiece.create(PieceId.ROOK_LABEL, ColorId.COLOR_BLACK));

					Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), imagePromotion.get(PieceId.BLACK_ROOK_LABEL));
					Game.setImage(cas, imagePromotion.get(PieceId.BLACK_ROOK_LABEL));
					board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
					Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());
					
					
					dispose();
				}
			});
		}
		else {
			try {
				img = ImageIO.read(getClass().getResource("White_Knight.png"));
				img = img.getScaledInstance(75, -1, Image.SCALE_DEFAULT);
				img1 = ImageIO.read(getClass().getResource("White_Bishop.png"));
				img1 = img1.getScaledInstance(75, -1, Image.SCALE_DEFAULT);
				img2 = ImageIO.read(getClass().getResource("White_Queen.png"));
				img2 = img2.getScaledInstance(75, -1, Image.SCALE_DEFAULT);
				img3 = ImageIO.read(getClass().getResource("White_Rook.png"));
				img3 = img3.getScaledInstance(75, -1, Image.SCALE_DEFAULT);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				img=null; img1=null; img2=null; img3=null;
				e.printStackTrace();
			}
			but1.setIcon(new ImageIcon(img)); but2.setIcon(new ImageIcon(img1)); but3.setIcon(new ImageIcon(img2)); but4.setIcon(new ImageIcon(img3));
			add(but1); add(but2); add(but3); add(but4);
			
			but1.addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					board.getChessBoard().put(cas,serviceAbstractPiece.create(PieceId.KNIGHT_LABEL, ColorId.COLOR_WHITE));

					Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), imagePromotion.get(PieceId.WHITE_KNIGHT_LABEL));
					Game.setImage(cas, imagePromotion.get(PieceId.WHITE_KNIGHT_LABEL));
					
					board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
					
					Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());
			
					dispose();
				}
			});
			
			but2.addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					board.getChessBoard().put(cas,serviceAbstractPiece.create(PieceId.BISHOP_LABEL, ColorId.COLOR_WHITE));

					Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), imagePromotion.get(PieceId.WHITE_BISHOP_LABEL));
					Game.setImage(cas, imagePromotion.get(PieceId.WHITE_BISHOP_LABEL));
					
					board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
					
					Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());

					
					dispose();
				}
			});
			
			but3.addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					board.getChessBoard().put(cas,serviceAbstractPiece.create(PieceId.QUEEN_LABEL, ColorId.COLOR_WHITE));

					Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), imagePromotion.get(PieceId.WHITE_QUEEN_LABEL));
					Game.setImage(cas, imagePromotion.get(PieceId.WHITE_QUEEN_LABEL));
					
					board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
					
					Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());

					
					dispose();
				}
			});
			
			but4.addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					board.getChessBoard().put(cas,serviceAbstractPiece.create(PieceId.ROOK_LABEL, ColorId.COLOR_WHITE));
					
					Game.setListeDeCase((Utils.getCoordinate(cas).get(PositionId.LINE) - 1), (Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1), imagePromotion.get(PieceId.WHITE_ROOK_LABEL));
					Game.setImage(cas, imagePromotion.get(PieceId.WHITE_ROOK_LABEL));
					Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].setDisabledIcon(Game.getListeDeCase()[(Utils.getCoordinate(cas).get(PositionId.LINE) - 1)][Utils.getCoordinate(cas).get(PositionId.COLUMN) - 1].getIcon());
					
					board.getChessBoard().get(cas).setPosition(Utils.getCoordinate(cas));
					
					dispose();
				}
			});
		}
		
		
		
		pack();
		setBounds(420, 0, 650, 150);
		setVisible(true);

	}
	

}
