package fr.projet.tihic.interfa;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.Timer;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.King;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.player.Player;
import fr.projet.tihic.reference.ColorId;
import fr.projet.tihic.reference.PieceId;
import fr.projet.tihic.reference.PositionId;
import fr.projet.tihic.service.imp.IA.ServiceIA;
import fr.projet.tihic.service.impl.board.ServiceBoard;
import fr.projet.tihic.service.impl.move.ServiceMove;
import fr.projet.tihic.service.impl.player.ServicePlayer;
import fr.projet.tihic.service.impl.rules.ServiceRules;
import fr.projet.tihic.utils.Utils;
import fr.projet.tihic.wip.WorkInProgress;

public class Game extends JFrame implements ActionListener{
	
	
	static Case[][] listeDeCase;
	static Map<String, ImageIcon> image;
	Board chessBoard;
	ServiceBoard serviceBoard;
	Image img;
	String posDepart, posFin;
	WorkInProgress work;
	ServiceMove service;
	ServiceIA serviceIa;
	List<String> possiblepath;
	ServicePlayer player;
	String ride; 
	ServiceRules serviceRule;
	List<Player> play;
	List<String> complique;
	List<String> complique2;	
	List<AbstractPiece> chaud;
	boolean echec;
	
	// attribut pour le timer
	private static int heure1=0,minute1=0,seconde1=0;
	private static int heure2=0,minute2=0,seconde2=0;
	Timer timer1;
	Timer timer2;
	
	JPanel timerPlayer1;
	JPanel timerPlayer2;
	
	
	// JLIST
	static JList<ImageIcon> jlist1;
	
	static DefaultListModel<ImageIcon> modele1;
	
	static JList<ImageIcon> jlist2;
	
	static DefaultListModel<ImageIcon> modele2;


	//Interface du jeu.
	public Game(Player p1, Player p2) {
		
		
		//title
		super("ChessGame");
		
		System.out.println(p1.getValueOfIA());
		//methods to close the window
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		echec = false;
		posDepart = null;
		posFin = null;
		possiblepath = new ArrayList<String>();
		complique = new ArrayList<String>();
		complique2 = new ArrayList<String>();
		chaud = new ArrayList<AbstractPiece>();
		
//		player = new ServicePlayer();
//		Player p1 = player.create("jojo", false, "Black");
//		Player p2 = player.create("greg", false, "White");
		work = new WorkInProgress(p1, p2);
		play = work.getPlayer();
		
		//TODO service IA a gerer dans frame1 ou alors faire des if ici.
		serviceIa = new ServiceIA();
		
		//timer
		
		int delais = 1000;
		ActionListener tache_timer1;
		ActionListener tache_timer2;
		
		setLayout(new BorderLayout());
		
		// panel nom joueur 1 et joueur 2
		JPanel player1name = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JLabel player1label = new JLabel(p1.getName());
		player1name.add(player1label);
		add(player1name, BorderLayout.NORTH);
		
		JPanel player2name = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JLabel player2label = new JLabel(p2.getName());
		player2name.add(player2label);
		add(player2name, BorderLayout.SOUTH);
		
		
		// Panel de l'échiquier 
		JPanel echiquier = new JPanel(new GridLayout(8, 8));
		//appel de serviceboard qui va nous permettre de gï¿½nï¿½rer l'echiquier 
		ServiceBoard serviceBoard = new ServiceBoard(); 
		//creation de l'echiquier initialiser
		chessBoard = serviceBoard.create();
		
		serviceRule = new ServiceRules();
		service = new ServiceMove();
		
		ride = ColorId.COLOR_WHITE;
		
		//creation hashmap pour la recuperation des coordonees i,j
		Map<String, Integer> initialPosition = new HashMap<String, Integer>();
		image = new HashMap<String, ImageIcon>();
		
		listeDeCase = new Case[8][8];
		//assigne un bouton case à chaque emplacement de la gridlayout
		for(int i=7; i>=0;i--) {
			for(int j=0; j<8; j++) {
				
				
				
				//ne pas faire i++ ou j++ car l'affecte ï¿½ i et j et du coup sort du tableau
				//pour ï¿½viter cela, faire simplement i+1 et j+1
				initialPosition.put(PositionId.COLUMN, j+1);
				initialPosition.put(PositionId.LINE, i+1);

				
				
				//vï¿½rifie si la case contient une piï¿½ce ou non
				if(chessBoard.getChessBoard().get(Utils.getPositionFromCoordinate(initialPosition))!=null) {
					
					//verifie la couleur de la piï¿½ce
					
					if(chessBoard.getChessBoard().get(Utils.getPositionFromCoordinate(initialPosition)).getColor()==ColorId.COLOR_BLACK) {
						//rï¿½cupï¿½re le type de la piï¿½ce et assigne l'image correspondante
						switch(chessBoard.getChessBoard().get(Utils.getPositionFromCoordinate(initialPosition)).getType()) {
						case PieceId.BISHOP_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("Black_Bishop.jpg"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							work.setImagePromotion(PieceId.BLACK_BISHOP_LABEL, new ImageIcon(img));
							work.setImagePromotionIa(PieceId.BISHOP_LABEL, new ImageIcon(img));
							
							break;
							
						case PieceId.KING_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("Black_King.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							break;
						case PieceId.KNIGHT_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("Black_Knight.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							work.setImagePromotion(PieceId.BLACK_KNIGHT_LABEL, new ImageIcon(img));
							work.setImagePromotionIa(PieceId.KNIGHT_LABEL, new ImageIcon(img));
							break;
						case PieceId.PAWN_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("Black_Pawn.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							break;
						case PieceId.QUEEN_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("Black_Queen.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							work.setImagePromotion(PieceId.BLACK_QUEEN_LABEL, new ImageIcon(img));
							work.setImagePromotionIa(PieceId.QUEEN_LABEL, new ImageIcon(img));
							break;
						case PieceId.ROOK_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("Black_Rook.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							work.setImagePromotion(PieceId.BLACK_ROOK_LABEL, new ImageIcon(img));
							work.setImagePromotionIa(PieceId.ROOK_LABEL, new ImageIcon(img));
							break;
						default:
							break;
						
						}
					}
					//si couleur est blanche
					if(chessBoard.getChessBoard().get(Utils.getPositionFromCoordinate(initialPosition)).getColor()==ColorId.COLOR_WHITE) {
						//rï¿½cupï¿½re le type de la piece est l'affiche
						switch(chessBoard.getChessBoard().get(Utils.getPositionFromCoordinate(initialPosition)).getType()) {
						case PieceId.BISHOP_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("White_Bishop.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							work.setImagePromotion(PieceId.WHITE_BISHOP_LABEL, new ImageIcon(img));
							break;
							
						case PieceId.KING_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("White_King.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							break;
						case PieceId.KNIGHT_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("White_Knight.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							work.setImagePromotion(PieceId.WHITE_KNIGHT_LABEL, new ImageIcon(img));
							break;
						case PieceId.PAWN_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("White_Pawn.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							break;
						case PieceId.QUEEN_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("White_Queen.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							work.setImagePromotion(PieceId.WHITE_QUEEN_LABEL, new ImageIcon(img));
							break;
						case PieceId.ROOK_LABEL:
							
							try {
								img = ImageIO.read(getClass().getResource("White_Rook.png"));
							} catch (IOException e) {
								// TODO Auto-generated catch block
								img=null;
								e.printStackTrace();
							}
							if ((i+j)%2==0)
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.WHITE);
							else
								listeDeCase[i][j] = new Case(new ImageIcon(img),Color.DARK_GRAY);
							image.put(Utils.getPositionFromCoordinate(initialPosition), new ImageIcon(img));
							work.setImagePromotion(PieceId.WHITE_ROOK_LABEL, new ImageIcon(img));
							break;
						default:
							break;
						
						}
					}
				}
				//Si case vide dans ce cas lï¿½ juste mettre des case blanche/noire

				else
				{
					if ((i+j)%2==0)
						listeDeCase[i][j] = new Case("",Color.WHITE);
					else
						listeDeCase[i][j] = new Case("",Color.DARK_GRAY);
					image.put(Utils.getPositionFromCoordinate(initialPosition), null);
				}
				
				//ajoutez les cases aux gridlayout
				listeDeCase[i][j].setActionCommand(Utils.getPositionFromCoordinate(initialPosition));
				listeDeCase[i][j].addActionListener(this);
				echiquier.add(listeDeCase[i][j]);
			}
			
			
		}
		
		add(echiquier, BorderLayout.CENTER);
		
		
		//panneau contenant timer et liste de pieces capturées
		JPanel panelInfo = new JPanel(new GridLayout(2, 1));
		JPanel panelInfo1 = new JPanel(new BorderLayout());
		JPanel panelInfo2 = new JPanel(new BorderLayout());
		
		
		//TIMER joueur 1
		timerPlayer1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		timerPlayer1.setBorder(BorderFactory.createLineBorder(Color.black));
		final JLabel label1 = new JLabel(heure1+":"+minute1+":"+seconde1); //d꤬are final car une classe interne va accꥥr ࡣe composant 
		
		tache_timer1=new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				seconde1++;
				if(seconde1==60)
				{
					seconde1=0;
					minute1++;
				}
				if(minute1==60)
				{
					minute1=0;
					heure1++;
				}
				label1.setText(heure1+":"+minute1+":"+seconde1);/* rafraichir le label */
			}
		};
		
		timer1 = new Timer(delais,tache_timer1);
		
		
		
		timerPlayer1.add(label1);
		panelInfo1.add(timerPlayer1,BorderLayout.NORTH);
		
		// TIMER JOUEUR 2
		
		timerPlayer2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		timerPlayer2.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		
		timerPlayer1.setBackground(Color.WHITE);
		timerPlayer2.setBackground(Color.WHITE);
		
		final JLabel label2 = new JLabel(heure2+":"+minute2+":"+seconde2);
		
		tache_timer2 = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				seconde2++;
				if (seconde2 == 60) {
					seconde2 = 0;
					minute2++;
				}
				if (minute2 == 60) {
					minute2 = 0;
					heure2++;
				}
				label2.setText(heure2 + ":" + minute2 + ":" + seconde2);/* rafraichir le label */
			}
		};
		
		timer2 = new Timer(delais,tache_timer2);
		
		
		
		
		
		jlist1 = new JList<ImageIcon>();
		
		modele1 = new DefaultListModel<ImageIcon>();
		
		jlist2 = new JList<ImageIcon>();
		
		modele2 = new DefaultListModel<ImageIcon>();
		
		jlist1.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		jlist2.setLayoutOrientation(JList.HORIZONTAL_WRAP);
		
		jlist1.setVisibleRowCount(4);
		jlist2.setVisibleRowCount(4);
		
		
		timerPlayer2.add(label2);
		panelInfo2.add(timerPlayer2,BorderLayout.NORTH);
		
		
		panelInfo1.add(jlist1);
		panelInfo.add(panelInfo1);
		panelInfo.add(panelInfo2);
		
		
		panelInfo2.add(jlist2);
		
		
		panelInfo.setPreferredSize(new Dimension(300, 500));
		
		add(panelInfo,BorderLayout.EAST);
				
		//pack = dimension optimale de la fenï¿½tre
		pack();
		
		//setBounds = positionner et dimensionner la fenï¿½tre
		setBounds(420, 0, 950, 750);
		
		//setVisible(true) rend la fenï¿½tre visible
		setVisible(true);
	}
	
	

	public static void setJlist1(ListModel<ImageIcon> jlist1) {
		Game.jlist1.setModel(jlist1);
	}




	public static DefaultListModel<ImageIcon> getModele1() {
		return modele1;
	}




	public static void setModele1(ImageIcon image) {
		Game.modele1.addElement(image);
	}


	public static void setJlist2(ListModel<ImageIcon> jlist2) {
		Game.jlist2.setModel(jlist2);
	}


	public static DefaultListModel<ImageIcon> getModele2() {
		return modele2;
	}


	public static void setModele2(ImageIcon image) {
		Game.modele2.addElement(image);
	}
	

	public static Case[][] getListeDeCase() {
		return listeDeCase;
	}

	public static void setListeDeCase(int i, int j, ImageIcon image) {
		Game.listeDeCase[i][j].setImage(image);
	}
	
	
	public static void setListeDeCaseHighLightPossible(int i, int j, boolean b) {
		Game.listeDeCase[i][j].setPossibleHighlight(b);
	}
	
	public static void setListeDeCaseHighLight(int i, int j, boolean b) {
		Game.listeDeCase[i][j].setHighlight(b);
	}

	public static Map<String, ImageIcon> getImage() {
		return image;
	}

	public static void setImage(String s, ImageIcon i) {
		image.put(s, i);
	}

	//Initialise l'echiquier au blanc.
	public void gameProgress() {
		
		String posDepart = null;
		List<Player> play = work.getPlayer();
		if(ride.equals(ColorId.COLOR_WHITE)) {
			timer2.start();
			timer1.stop();
			timerPlayer2.setBackground(Color.gray);
			
		}
		
		
		
		updateTable(ride, play, service, posDepart, chaud);
		
	}
	
	//MÃ©thode permetant l'update de l'echiquier.
	public void updateTable(String ride,List<Player> play, ServiceMove service, String posDepart, List<AbstractPiece> chaud) {
		
		List<String> possiblePath = new ArrayList<String>();
		Map<String, Integer> possibleClick = new HashMap<String, Integer>();
		
		
		if (posDepart == null) {
			for(int i=7; i>=0;i--) {
				for(int j=0; j<8; j++) {
					listeDeCase[i][j].setEnabled(true);
				}
			}
			if (ride == ColorId.COLOR_WHITE) {

				if(serviceRule.echecCheck(chessBoard, service, ColorId.COLOR_BLACK)){
					for (int i = 7; i >= 0; i--) {
						for (int j = 0; j < 8; j++) {
							listeDeCase[i][j].setEnabled(false);
							listeDeCase[i][j].setDisabledIcon(listeDeCase[i][j].getIcon());
						}
					}
					if (!chaud.isEmpty()) {
						for (int i = 0; i < chaud.size(); i++) {
							possibleClick = chaud.get(i).getPosition();
							int colum = possibleClick.get(PositionId.COLUMN) - 1;
							int line = possibleClick.get(PositionId.LINE) - 1;

							listeDeCase[line][colum].setEnabled(true);
						}

					}
				}

				else {
					for (Map.Entry<String, AbstractPiece> entry : chessBoard.getChessBoard().entrySet()) {

						if (entry.getValue() == null || entry.getValue().getColor() == ColorId.COLOR_BLACK) {

							possibleClick = Utils.getCoordinate(entry.getKey());
							int colum = possibleClick.get(PositionId.COLUMN) - 1;
							int line = possibleClick.get(PositionId.LINE) - 1;

							listeDeCase[line][colum].setEnabled(false);
							listeDeCase[line][colum].setDisabledIcon(listeDeCase[line][colum].getIcon());
						}
					}
				}
			} else {
				
				
				if(serviceRule.echecCheck(chessBoard, service, ColorId.COLOR_WHITE)){
					for (int i = 7; i >= 0; i--) {
						for (int j = 0; j < 8; j++) {
							listeDeCase[i][j].setEnabled(false);
							listeDeCase[i][j].setDisabledIcon(listeDeCase[i][j].getIcon());
						}
					}
					if (!chaud.isEmpty()) {
						for (int i = 0; i < chaud.size(); i++) {
							possibleClick = chaud.get(i).getPosition();
							int colum = possibleClick.get(PositionId.COLUMN) - 1;
							int line = possibleClick.get(PositionId.LINE) - 1;

							listeDeCase[line][colum].setEnabled(true);
						}

					}
				}
				else {
					for (Map.Entry<String, AbstractPiece> entry : chessBoard.getChessBoard().entrySet()) {
						if (entry.getValue() == null || entry.getValue().getColor() == ColorId.COLOR_WHITE) {

							possibleClick = Utils.getCoordinate(entry.getKey());
							int colum = possibleClick.get(PositionId.COLUMN) - 1;
							int line = possibleClick.get(PositionId.LINE) - 1;

							listeDeCase[line][colum].setEnabled(false);
							listeDeCase[line][colum].setDisabledIcon(listeDeCase[line][colum].getIcon());

						}
					}
				}
			}
		}
		else{
			if (serviceRule.echecCheck(chessBoard, service, ColorId.COLOR_BLACK) || serviceRule.echecCheck(chessBoard, service, ColorId.COLOR_WHITE)) {
				possiblePath = chessBoard.getChessBoard().get(posDepart).getPossiblePath();
				
				for (int i = 7; i >= 0; i--) {
					for (int j = 0; j < 8; j++) {
						listeDeCase[i][j].setEnabled(false);
						listeDeCase[i][j].setDisabledIcon(listeDeCase[i][j].getIcon());
					}
				}
				
				for (int i = 0; i < possiblePath.size(); i++) {
					if (possiblePath.get(i) != null) {
						possibleClick = Utils.getCoordinate(possiblePath.get(i));
						int colum = possibleClick.get(PositionId.COLUMN) - 1;
						int line = possibleClick.get(PositionId.LINE) - 1;

						listeDeCase[line][colum].setEnabled(true);
					}
				}

				possibleClick = Utils.getCoordinate(posDepart);
				int colum = possibleClick.get(PositionId.COLUMN) - 1;
				int line = possibleClick.get(PositionId.LINE) - 1;

				listeDeCase[line][colum].setEnabled(true);
				
			} else {
				possiblePath = service.getMove(chessBoard.getChessBoard().get(posDepart), chessBoard, false, false, true, false, null);
				
				if (ride == ColorId.COLOR_WHITE) {
					possiblePath.addAll(serviceRule.castling(chessBoard, ColorId.COLOR_WHITE));
				}
				else if(ride == ColorId.COLOR_BLACK) {
					possiblePath.addAll(serviceRule.castling(chessBoard, ColorId.COLOR_BLACK));
				}

				for (int i = 7; i >= 0; i--) {
					for (int j = 0; j < 8; j++) {
						listeDeCase[i][j].setEnabled(false);
						listeDeCase[i][j].setDisabledIcon(listeDeCase[i][j].getIcon());
					}
				}

				for (int i = 0; i < possiblePath.size(); i++) {
					if (possiblePath.get(i) != null) {
						possibleClick = Utils.getCoordinate(possiblePath.get(i));
						int colum = possibleClick.get(PositionId.COLUMN) - 1;
						int line = possibleClick.get(PositionId.LINE) - 1;

						listeDeCase[line][colum].setEnabled(true);
					}
				}

				possibleClick = Utils.getCoordinate(posDepart);
				int colum = possibleClick.get(PositionId.COLUMN) - 1;
				int line = possibleClick.get(PositionId.LINE) - 1;

				listeDeCase[line][colum].setEnabled(true);

			}
		}
	}

	//Action du ou des joueurs.
	@Override
	public void actionPerformed(ActionEvent e) {

		if (posDepart == null) {
			posDepart = e.getActionCommand();
			updateTable(ride, play, service, posDepart, chaud);
			possiblepath = work.initializeRound(chessBoard, service, serviceRule, posDepart, possiblepath, ride);
			if(possiblepath.isEmpty()) {
				new EchecMattInterface(this);
			}
			if(ride.equals(ColorId.COLOR_WHITE)) {
				timer2.start();
				timer1.stop();
				timerPlayer2.setBackground(Color.gray);
				timerPlayer1.setBackground(Color.WHITE);
			}
			else if(ride.equals(ColorId.COLOR_BLACK)) {
				timer1.start();
				timer2.stop();
				timerPlayer1.setBackground(Color.gray);
				timerPlayer2.setBackground(Color.WHITE);
			}
			
		} else {
			if (posDepart.equals(e.getActionCommand())) {

				work.interHighLight(posDepart, possiblepath);

				posDepart = null;
				updateTable(ride, play, service, posDepart, chaud);
			} else {
				posFin = e.getActionCommand();

				work.interHighLight(posDepart, possiblepath);

				work.gameProgress(posFin, posDepart, ride, chessBoard);

				if (ride == ColorId.COLOR_WHITE)
					serviceRule.promotion(chessBoard, work.getPlayer().get(0), work, this);
				else
					serviceRule.promotion(chessBoard, work.getPlayer().get(1), work, this);

				chessBoard.getChessBoard().get(posFin).setPosition(Utils.getCoordinate(posFin));
				chessBoard.getChessBoard().get(posFin).setPossiblePath(null);

				serviceRule.castlingProgress(chessBoard, posFin, ride);

				work.setFirstMovePiece(posDepart, posFin, ride, chessBoard, serviceRule, work);

				if (serviceRule.echecCheck(chessBoard, service, ride)) {
					chaud = serviceRule.echecMat(ride, service, chessBoard, work, chaud);
					if (chaud.isEmpty()) {
						echec = true;
						System.out.println("echec et mat");
						new EchecMattInterface(this);
						//TODO jdialog echec et matt
					}
				}

				if (ride == ColorId.COLOR_WHITE) {
					WorkInProgress.setNbcoup_tot((WorkInProgress.getNbcoup_tot() + 1));
					
					if (play.get(1).isIA() && !echec) {
						//updateTable(ride, play, service, posDepart, chaud);
						boolean move = serviceIa.moveIA(chessBoard, service, serviceRule, work, chaud, posDepart, posFin, work.getPlayer().get(1).getValueOfIA(), this);
						
						//if(!move)System.out.println("echec et mat");
							
						if(!move)System.out.println("echec et mat");
						
						if (serviceRule.echecCheck(chessBoard, service, ColorId.COLOR_BLACK)) {
							chaud = serviceRule.echecMat(ColorId.COLOR_BLACK, service, chessBoard, work, chaud);
							if (chaud.isEmpty())
								System.out.println("echec et mat");	
						}
						
					}else ride = ColorId.COLOR_BLACK;
				} else {
					WorkInProgress.setNbcoup_tot((WorkInProgress.getNbcoup_tot() + 1));
					ride = ColorId.COLOR_WHITE;
				}

				if(ride.equals(ColorId.COLOR_WHITE)) {
					timer2.start();
					timer1.stop();
					timerPlayer2.setBackground(Color.gray);
					timerPlayer1.setBackground(Color.WHITE);
				}
				else if(ride.equals(ColorId.COLOR_BLACK)) {
					timer1.start();
					timer2.stop();
					timerPlayer1.setBackground(Color.gray);
					timerPlayer2.setBackground(Color.WHITE);
				}
				System.out.println("Fin : " + posFin);
				posDepart = null;
				posFin = null;
				updateTable(ride, play, service, posDepart, chaud);
			}
		}

	}
	
	public static void main(String[] args) {
		ServicePlayer player = new ServicePlayer();
		
		Player p1 = player.create("jojo", false, "Black", 0);
		Player p2 = player.create("greg", false, "White", 0);
		Game g = new Game(p1, p2);
		g.gameProgress();
		
	}

}
