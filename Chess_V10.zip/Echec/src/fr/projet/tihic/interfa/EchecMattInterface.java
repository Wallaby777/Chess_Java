package fr.projet.tihic.interfa;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

public class EchecMattInterface extends JDialog  {

	Game game;
	
	
	public EchecMattInterface(Game game) {
		super(game,"Echec et Matt", true);
		this.game=game;
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setLayout(new BorderLayout());
		
		JPanel rejouerBouton = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton rejouer = new JButton("PLAY AGAIN");
		
		rejouer.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Frame1();
				game.dispose();
				dispose();
				
			}
		});
		
		rejouerBouton.add(rejouer);
		
		add(rejouerBouton, BorderLayout.SOUTH);
		
		
		
		pack();
		setBounds(420, 0, 750, 750);
		
		setVisible(true);
	}
}
