package fr.projet.tihic.interfa;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import fr.projet.tihic.player.Player;
import fr.projet.tihic.service.impl.player.ServicePlayer;

public class Frame1 extends JFrame {

	int forceIA;
	
	public Frame1() {
		super("ChessMaster");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new GridLayout(1,2));
		
		try {
			//Creation d'un JPanel
			JPanel imagePanel = new JPanel() {
				//Chargement de l'image avec BufferedImage
				BufferedImage img = ImageIO.read(Frame1.class.getResource("principal.png"));
				
				//We override a method used to draw the content of the JPanel
				//so that it will draw our image
				
				@Override
				public void paintComponent(Graphics g) {
					setSize(new Dimension(img.getWidth(),img.getHeight()));
					g.drawImage(img, 0, 0, null);
				}
			};
			
			//FInally, we add it to the window
			add(imagePanel);
		} catch(IOException e) {
			e.printStackTrace();
		}
		
		
		
		JPanel partieDroite = new JPanel(new GridLayout(2, 1));
		JPanel pvp = new JPanel(new GridLayout(4, 1));
		
		JPanel champLegende = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel legende = new JLabel("Player Vs Player");
		champLegende.add(legende);
		pvp.add(champLegende);
		
		JPanel player1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel nomPlayer1 = new JLabel("player 1: ");
		player1.add(nomPlayer1);
		JTextField champPlayer1 = new JTextField(20);
		player1.add(champPlayer1);
		pvp.add(player1);
		
		
		JPanel player2 = new JPanel( new FlowLayout(FlowLayout.CENTER));
		JLabel nomPlayer2 = new JLabel("player 2: ");
		player2.add(nomPlayer2);
		JTextField champPlayer2 = new JTextField(20);
		player2.add(champPlayer2);
		player2.setPreferredSize(player1.getPreferredSize());
		pvp.add(player2);
		
		JPanel jouerButton = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton jouerPvp = new JButton("PLAY");
		
		jouerPvp.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ServicePlayer joueurs = new ServicePlayer();
				String nomDuJoueur1=champPlayer1.getText();
				String nomDuJoueur2=champPlayer2.getText();
				
				//pouvoir r�cup�rer la valeur des JRADIOBUTTON pour la cr�ation de l'IA
				Player p1 = joueurs.create(nomDuJoueur1, false, "Black", 0);
				Player p2 = joueurs.create(nomDuJoueur2, false, "White", 0);
				Game game = new Game(p1, p2);
				game.gameProgress();
				dispose();
			}
		});
		
		
		jouerButton.add(jouerPvp);
		pvp.add(jouerButton);
		
		partieDroite.add(pvp);
		
		
		
		JPanel pvIa = new JPanel(new GridLayout(6, 1));
		
		JPanel champLegende2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel legende2 = new JLabel("Player Vs IA");
		champLegende2.add(legende2);
		pvIa.add(champLegende2);
		
		JPanel player = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel nomPlayer = new JLabel("player 1: ");
		player.add(nomPlayer);
		JTextField champPlayer = new JTextField(20);
		player.add(champPlayer);
		pvIa.add(player);
		
		JPanel radioButton1 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JRadioButton niv1 = new JRadioButton("IA level 1");
		radioButton1.add(niv1);
		pvIa.add(radioButton1);
		
		niv1.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				forceIA=1;

			}
		});
		
		JPanel radioButton2 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JRadioButton niv2 = new JRadioButton("IA level 2");
		radioButton2.add(niv2);
		pvIa.add(radioButton2);
		
		niv2.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				forceIA=2;

			}
		});
		
		JPanel radioButton3 = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JRadioButton niv3 = new JRadioButton("IA level 3");
		radioButton3.add(niv3);
		pvIa.add(radioButton3);
		
		niv3.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				forceIA=3;

			}
		});
		
		
		//bouton pour lancer game avec IA
		JPanel jouerButtonIa = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton jouerPvIa = new JButton("PLAY");
		
		jouerPvIa.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				ServicePlayer joueurs = new ServicePlayer();
				String nomDuJoueur=champPlayer.getText();
				
				//pouvoir r�cup�rer la valeur des JRADIOBUTTON pour la cr�ation de l'IA
				Player p1 = joueurs.create("Multivac", true, "Black", forceIA);
				Player p2 = joueurs.create(nomDuJoueur, false, "White", 0);
				
				Game game = new Game(p1, p2);
				game.gameProgress();
				dispose();
				
			}
		});
		
		jouerButtonIa.add(jouerPvIa);
		pvIa.add(jouerButtonIa);
		
		
		partieDroite.add(pvIa);
		
		add(partieDroite);
		
		
		
		ButtonGroup levelIA = new ButtonGroup();
		levelIA.add(niv1);
		levelIA.add(niv2);
		levelIA.add(niv3);
		
		
		validate();
		pack();
		setBounds(420, 42, 950, 447);
		
		setVisible(true);
		
	}
	
	public static void main(String[] args) {
		new Frame1();
		
	}

}
