package fr.projet.tihic.exec;

import java.util.HashMap;
import java.util.Map;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.reference.PieceId;
import fr.projet.tihic.reference.PositionId;
import fr.projet.tihic.service.impl.board.ServiceBoard;
import fr.projet.tihic.service.impl.move.ServiceMove;
import fr.projet.tihic.service.impl.piece.ServiceAbstractPiece;
import fr.projet.tihic.utils.Utils;
import fr.projet.tihic.wip.WorkInProgress;

public class Main {
	// M�thode permettant de r�cup�rer les coordon�es � partir d'une position

	// M�thode pour cr�ation de piece setting du board.

	// public static

	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//		//
//		// String position = "B6";
//		// Pawn pawn = new Pawn();
//		// // System.out.println(getCoordinate(position).toString());
//		// pawn.setPosition(Utils.getCoordinate(position));
//		//
//		// System.out.println("position : " + position);
//		// System.out
//		// .println("pawn position : " + pawn.getPosition().get(PositionId.COLUMN) + ",
//		// " +
//		// pawn.getPosition().get(PositionId.LINE));
//		// // System.out.println(pawn.getPosition().get(PositionId.COLUMN)+1);
//		// System.out.println("position : " +
//		// Utils.getPositionFromCoordinate(pawn.getPosition()));
//		//// ServiceAbstractPiece serviceAbstractPiece = new ServiceAbstractPiece();
//		//// Pawn pawn = (Pawn) serviceAbstractPiece.create(PieceId.PAWN_LABEL);
//		//// System.out.println(pawn.getValueForIA());
//		//
//		ServiceBoard serviceBoard = new ServiceBoard();
//		Board boardToTest = serviceBoard.create();
//		ServiceMove serviceMove = new ServiceMove();
//		WorkInProgress work = new WorkInProgress();
//
//		Rook rookToMove = (Rook) boardToTest.getChessBoard().get("A1");
//		System.out.println(rookToMove);
//		boardToTest.getChessBoard().replace("A1", null);
//		boardToTest.getChessBoard().replace("B4", rookToMove);
//		// if (boardToTest.getChessBoard().get("A1") != null) {
//		// System.out.println("A1 : ");
//		// System.out.println(boardToTest.getChessBoard().get("A1"));
//		// }
//		// if (boardToTest.getChessBoard().get("B4") != null) {
//		// System.out.println("B4 : ");
//		// System.out.println(boardToTest.getChessBoard().get("B4"));
//		// }
//		System.out.println(rookToMove);
//
//		boardToTest.getChessBoard().get("B4").setPosition(Utils.getCoordinate("B4"));
//		System.out.println(rookToMove.getPosition().get(PositionId.LINE));
//		boardToTest.getChessBoard().get("B4").setPossiblePath(serviceMove.getMove(boardToTest.getChessBoard().get("B4"), boardToTest, work));
//
//		System.out.println(boardToTest.getChessBoard().get("B4").getPossiblePath().toString());

	}

}
