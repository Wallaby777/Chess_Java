package fr.projet.tihic.reference;

public class PositionId {
	
	public final static String COLUMN = "column";
	public final static String LINE = "line";

}
