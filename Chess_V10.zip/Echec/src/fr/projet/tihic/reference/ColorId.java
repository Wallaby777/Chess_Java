package fr.projet.tihic.reference;

public class ColorId {

	public final static String COLOR_BLACK = "Black";
	public final static String COLOR_WHITE = "White";
	
}
