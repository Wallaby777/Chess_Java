package fr.projet.tihic.reference;

public class PieceId {
	
	public final static String PAWN_LABEL = "Pawn";
	public final static String ROOK_LABEL = "Roc";
	public final static String KNIGHT_LABEL = "Knight";
	public final static String BISHOP_LABEL = "Bishop";
	public final static String QUEEN_LABEL = "Queen";
	public final static String KING_LABEL = "King";
	
	public final static String BLACK_PAWN_LABEL = "Pawn_B";
	public final static String BLACK_ROOK_LABEL = "Roc_B";
	public final static String BLACK_KNIGHT_LABEL = "Knight_B";
	public final static String BLACK_BISHOP_LABEL = "Bishop_B";
	public final static String BLACK_QUEEN_LABEL = "Queen_B";
	public final static String BLACK_KING_LABEL = "King_B";
	
	public final static String WHITE_PAWN_LABEL = "Pawn_W";
	public final static String WHITE_ROOK_LABEL = "Roc_W";
	public final static String WHITE_KNIGHT_LABEL = "Knight_W";
	public final static String WHITE_BISHOP_LABEL = "Bishop_W";
	public final static String WHITE_QUEEN_LABEL = "Queen_W";
	public final static String WHITE_KING_LABEL = "King_W";
	
}
