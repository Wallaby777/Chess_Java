package fr.projet.tihic.player;

import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;

public class Player {

	String name;
	String color;
	boolean isIA;
	ArrayList<String> shot;
	ImageIcon prise;
	float time;
	int valueOfIA;

	

	public Player(){
		super();
		shot = new ArrayList<String>();
		valueOfIA=0;
	}
	
	public int getValueOfIA() {
		return valueOfIA;
	}

	public void setValueOfIA(int valueOfIA) {
		this.valueOfIA = valueOfIA;
	}

	
	public ImageIcon getPrise() {
		return prise;
	}


	public void setPrise(ImageIcon prise) {
		this.prise = prise;
	}

	public float getTime() {
		return time;
	}


	public void setTime(float time) {
		this.time = time;
	}


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isIA() {
		return isIA;
	}

	public void setIA(boolean isIA) {
		this.isIA = isIA;
	}
	
	public ArrayList<String> getShot() {
		return shot;
	}

	public void setShot(String shot) {
		this.shot.add(shot);
	}

}
