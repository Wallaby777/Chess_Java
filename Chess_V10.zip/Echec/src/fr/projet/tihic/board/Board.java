package fr.projet.tihic.board;

import java.util.HashMap;
import java.util.Map;

import fr.projet.tihic.piece.AbstractPiece;

public class Board {

	private Map<String, AbstractPiece> chessBoard;

	public Board() {
		super();
	}

	public Map<String, AbstractPiece> getChessBoard() {
		return chessBoard;
	}

	public void setChessBoard(Map<String, AbstractPiece> chessBoard) {
		this.chessBoard = chessBoard;
	}
	
	

}
