package fr.projet.tihic.wip;




import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.ImageIcon;

import fr.projet.tihic.board.Board;
import fr.projet.tihic.interfa.Case;
import fr.projet.tihic.interfa.Game;
import fr.projet.tihic.piece.AbstractPiece;
import fr.projet.tihic.piece.King;
import fr.projet.tihic.piece.Pawn;
import fr.projet.tihic.piece.Rook;
import fr.projet.tihic.player.Player;
import fr.projet.tihic.reference.ColorId;
import fr.projet.tihic.reference.PositionId;
import fr.projet.tihic.service.impl.move.ServiceMove;
import fr.projet.tihic.service.impl.rules.ServiceRules;
import fr.projet.tihic.utils.Utils;
import fr.projet.tihic.service.IServiceMove;

public class WorkInProgress{
	
	static int nbcoup_tot;
	List <Player> player;
	Map<String, ImageIcon> imagePromotion;
	Map<String, ImageIcon> imagePromotionIa;

	public WorkInProgress(Player p1, Player p2){
		
		nbcoup_tot = 0 ;
		
		player = new ArrayList <Player>();
		imagePromotion = new HashMap<String, ImageIcon>();
		imagePromotionIa = new HashMap<String, ImageIcon>();
		
		if(p1.getColor() == ColorId.COLOR_WHITE) {
			player.add(p1);
			player.add(p2);
		}
		else {
			player.add(p2);
			player.add(p1);	
		}
		
	}
	
	

	public Map<String, ImageIcon> getImagePromotionIa() {
		return imagePromotionIa;
	}



	public void setImagePromotionIa(String s, ImageIcon image) {
		imagePromotionIa.put(s, image);
	}



	public Map<String, ImageIcon> getImagePromotion() {
		return imagePromotion;
	}

	public void setImagePromotion(String s, ImageIcon image) {
		imagePromotion.put(s, image);
	}

	public List<Player> getPlayer() {
		return player;
	}

	public void setPlayer(List<Player> player) {
		this.player = player;
	}

	public static int getNbcoup_tot() {
		return nbcoup_tot;
	}

	public static void setNbcoup_tot(int i) {
		nbcoup_tot = i;
	}
	

	//Progression du jeu et du board.
	public void gameProgress(String posFin, String posDepart, String ride, Board chessBoard){
		
		if (Game.getImage().get(posFin) != null) {

			if (ride == ColorId.COLOR_WHITE) {
				getPlayer().get(0).setPrise(Game.getImage().get(posFin));
				Game.setModele2(getPlayer().get(0).getPrise());
				Game.setJlist2(Game.getModele2());
			}
			else {
				getPlayer().get(1).setPrise(Game.getImage().get(posFin));
				getPlayer().get(1).setPrise(Game.getImage().get(posFin));
				Game.setModele1(getPlayer().get(1).getPrise());
				Game.setJlist1(Game.getModele1());
			}
		}	
		
		Game.setListeDeCase((Utils.getCoordinate(posFin).get(PositionId.LINE) - 1),
				(Utils.getCoordinate(posFin).get(PositionId.COLUMN) - 1), Game.getImage().get(posDepart));

		Game.setListeDeCase((Utils.getCoordinate(posDepart).get(PositionId.LINE) - 1),
				(Utils.getCoordinate(posDepart).get(PositionId.COLUMN) - 1), null);

		Game.setImage(posFin, Game.getImage().get(posDepart));
		Game.setImage(posDepart, null);

		if (chessBoard.getChessBoard().get(posDepart) instanceof Pawn) {
			Pawn pawn = (Pawn) chessBoard.getChessBoard().get(posDepart);
			if (!Utils.getCoordinate(posFin).get(PositionId.COLUMN)
					.equals(Utils.getCoordinate(posDepart).get(PositionId.COLUMN))
					&& chessBoard.getChessBoard().get(posFin) == null) {

				for (Map.Entry<String, Integer> entry : pawn.getEnPassant().entrySet()) {
					if (entry.getValue() == (WorkInProgress.getNbcoup_tot() - 1)) {

						Game.setListeDeCase((Utils.getCoordinate(entry.getKey()).get(PositionId.LINE) - 1),
								(Utils.getCoordinate(entry.getKey()).get(PositionId.COLUMN) - 1), null);
						
						Game.setImage(entry.getKey(), null);

					}
				}

			}

			

		}
		 
		
		chessBoard.getChessBoard().put(posFin, chessBoard.getChessBoard().get(posDepart));
		chessBoard.getChessBoard().put(posDepart, null);
		
	}
	
	//Initialisation du tour.
	public List<String> initializeRound(Board chessBoard, ServiceMove service, ServiceRules serviceRule, String posDepart, List<String> possiblepath, String ride) {
		
		Game.setListeDeCaseHighLightPossible((Utils.getCoordinate(posDepart).get(PositionId.LINE) - 1), (Utils.getCoordinate(posDepart)
				.get(PositionId.COLUMN) - 1), true);
		
		if (serviceRule.echecCheck(chessBoard, service, ColorId.COLOR_BLACK)
				|| serviceRule.echecCheck(chessBoard, service, ColorId.COLOR_WHITE))
			possiblepath = chessBoard.getChessBoard().get(posDepart).getPossiblePath();
		else {
			possiblepath = service.getMove(chessBoard.getChessBoard().get(posDepart), chessBoard, false, false, true,
					false, null);
			if (ride == ColorId.COLOR_WHITE && chessBoard.getChessBoard().get(posDepart) instanceof King)
				possiblepath.addAll(serviceRule.castling(chessBoard, ride));
			else if (ride == ColorId.COLOR_BLACK && chessBoard.getChessBoard().get(posDepart) instanceof King)
				possiblepath.addAll(serviceRule.castling(chessBoard, ride));
			chessBoard.getChessBoard().get(posDepart).setPossiblePath(possiblepath);
		}

		if (possiblepath != null) {
			for (int i = 0; i < possiblepath.size(); i++) {
				if (possiblepath.get(i) != null)
					Game.setListeDeCaseHighLight((Utils.getCoordinate(possiblepath.get(i)).get(PositionId.LINE) - 1), (Utils
							.getCoordinate(possiblepath.get(i)).get(PositionId.COLUMN) - 1), true);
			}
		}
		return possiblepath;
	}
	
	//Méthode permetant de mettre en surbrillance les cases de destination possible pour une piece donnée.
	public void interHighLight(String posDepart, List<String> possiblepath) {
		Game.setListeDeCaseHighLightPossible((Utils.getCoordinate(posDepart).get(PositionId.LINE) - 1), (Utils.getCoordinate(posDepart)
				.get(PositionId.COLUMN) - 1), false);

		if (possiblepath != null) {
			for (int i = 0; i < possiblepath.size(); i++) {
				if (possiblepath.get(i) != null)
					Game.setListeDeCaseHighLight((Utils.getCoordinate(possiblepath.get(i)).get(PositionId.LINE) - 1), (Utils
							.getCoordinate(possiblepath.get(i)).get(PositionId.COLUMN) - 1), false);
			}
		}
	}
	
	//Set le status Mouvement du pion et de la tour, plus verifie si une situation enPassant et possible auquel cas declaration.
	public void setFirstMovePiece(String posDepart, String posFin, String ride, Board chessBoard, ServiceRules serviceRule, WorkInProgress work) {
		if (chessBoard.getChessBoard().get(posFin) instanceof Pawn) {
			Pawn pawn = (Pawn) chessBoard.getChessBoard().get(posFin);
			serviceRule.enPassant(chessBoard, posDepart, posFin, work);
		}

		if (chessBoard.getChessBoard().get(posFin) instanceof Rook) {
			Rook rook = (Rook) chessBoard.getChessBoard().get(posFin);
			rook.setIsFirstMove(false);
		}
	}

}
